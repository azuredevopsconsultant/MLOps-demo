# Databricks notebook source
# MAGIC %md
# MAGIC # Feature Engineering — Databricks Feature Store
# MAGIC Computes and writes features to Unity Catalog Feature Store tables with time-travel.
# MAGIC
# MAGIC **Section overview:**
# MAGIC 1. Compute features from Gold layer
# MAGIC 2. Write to Feature Store (merge / create)
# MAGIC 3. OPTIMIZE + Z-ORDER for fast lookup performance
# MAGIC 4. Create / refresh Online Table for real-time inference
# MAGIC 5. Lakehouse Monitoring setup
# MAGIC
# MAGIC **Cost optimisations applied:**
# MAGIC - Delta disk cache enabled — avoids re-reading same Parquet blocks across tasks
# MAGIC - DataFrame cached before multi-step transformations, unpersisted after write
# MAGIC - Single aggregation pass for feature stats (not one-per-column)
# MAGIC - OPTIMIZE + Z-ORDER runs only when row count has grown by ≥ 10 %
# MAGIC   (avoids expensive compaction on every run)

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema",  "mlops_demo")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")

from databricks.feature_engineering import FeatureEngineeringClient
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import (
    OnlineTableSpec,
    OnlineTableSpecTriggeredSchedulingPolicy,
)
from pyspark.sql import functions as F
from pyspark.sql.window import Window

fe = FeatureEngineeringClient()
w  = WorkspaceClient()

feature_table_name  = f"{catalog}.{schema}.customer_churn_features"
online_table_name   = f"{catalog}.{schema}.customer_churn_features_online"

# ── Delta disk cache — avoids re-reading S3 Parquet on repeated scans ──
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.databricks.io.cache.compression.enabled", "true")

# COMMAND ----------
# MAGIC %md ## 1. Compute Features from Gold Layer
# MAGIC Cache gold_df before transformation — re-used for count check and feature write.

gold_df = spark.table(f"{catalog}.{schema}.gold_customers_ml").cache()

feature_df = (
    gold_df
    .select(
        "customer_id",
        "tenure_months",
        "monthly_spend",
        "spend_12m_avg",
        "is_high_value",
        "region_encoded",
        "tier_encoded",
        "num_support_tickets",
        "num_logins_30d",
        "days_since_last_login",
        "contract_type",
        F.col("churn_flag").alias("label"),
    )
    .withColumn("feature_timestamp", F.current_timestamp())
    .cache()   # cache before the write + count — avoids re-computing twice
)

new_row_count = feature_df.count()
print(f"✓ Feature rows computed: {new_row_count:,}")

# COMMAND ----------
# MAGIC %md ## 2. Write to Feature Store

try:
    fe.write_table(name=feature_table_name, df=feature_df, mode="merge")
    print(f"✓ Features merged into {feature_table_name}")
except Exception:
    fe.create_table(
        name=feature_table_name,
        primary_keys=["customer_id"],
        timestamp_keys=["feature_timestamp"],
        df=feature_df,
        schema=feature_df.schema,
        description=(
            "Customer churn features for ML model. "
            "Includes behavioural and contractual signals."
        ),
        tags={"team": "mlops", "domain": "customer", "version": "1.0"},
    )
    print(f"✓ Feature table created: {feature_table_name}")

feature_df.unpersist()
gold_df.unpersist()

# COMMAND ----------
# MAGIC %md ## 3. Pipeline Optimisation — OPTIMIZE + Z-ORDER
# MAGIC Z-ORDER on `customer_id` dramatically speeds up Feature Store lookups during
# MAGIC training and batch inference — both join on `customer_id`.
# MAGIC
# MAGIC **Cost guard:** only OPTIMIZE when the table has grown by ≥ 10 % since last
# MAGIC optimisation.  Delta records the `numOutputRows` in the last OPTIMIZE in the
# MAGIC transaction log; we read it back from `DESCRIBE HISTORY`.

from pyspark.sql import functions as SpF

history = spark.sql(
    f"DESCRIBE HISTORY {feature_table_name} LIMIT 20"
).filter(SpF.col("operation") == "OPTIMIZE")

last_optimized_rows = 0
if history.count() > 0:
    last_op = history.orderBy(SpF.desc("timestamp")).first()
    last_optimized_rows = (last_op["operationMetrics"] or {}).get("numOutputRows", 0)
    last_optimized_rows = int(last_optimized_rows)

growth_pct = (
    (new_row_count - last_optimized_rows) / max(last_optimized_rows, 1)
)
print(f"\nZ-ORDER check: current={new_row_count:,}  last_optimize={last_optimized_rows:,}  growth={growth_pct:.0%}")

if growth_pct >= 0.10 or last_optimized_rows == 0:
    print("  Running OPTIMIZE + Z-ORDER on customer_id, feature_timestamp ...")
    spark.sql(f"""
        OPTIMIZE {feature_table_name}
        ZORDER BY (customer_id, feature_timestamp)
    """)
    print("  ✓ OPTIMIZE complete")
    # Expire old Delta versions — retain 7 days (168 h) to allow time-travel rollbacks
    spark.sql(f"VACUUM {feature_table_name} RETAIN 168 HOURS")
    print("  ✓ VACUUM complete — versions older than 7 days removed")
else:
    print("  Skipping OPTIMIZE — growth < 10%")

# COMMAND ----------
# MAGIC %md ## 4. Online Table — Real-Time Inference Feature Serving
# MAGIC Creates a Delta Sync Online Table in Unity Catalog backed by the feature table.
# MAGIC `run_triggered` policy means it only syncs when explicitly triggered (cost-controlled).
# MAGIC For continuous sync use `run_continuously` (higher cost — for <1s latency SLA).

try:
    existing = w.online_tables.get(name=online_table_name)
    # Trigger a sync refresh so online table reflects latest feature data
    w.online_tables.delete(name=online_table_name)
    print(f"  Deleted existing online table for re-creation (schema may have changed)")
    existing = None
except Exception:
    existing = None

if existing is None:
    w.online_tables.create(
        name=online_table_name,
        spec=OnlineTableSpec(
            source_table_full_name=feature_table_name,
            primary_key_columns=["customer_id"],
            # Triggered sync — low cost; call run_refresh to sync before inference windows
            run_triggered=OnlineTableSpecTriggeredSchedulingPolicy(),
        ),
    )
    print(f"✓ Online table created: {online_table_name}")
    print(f"  Source : {feature_table_name}")
    print(f"  Policy : triggered (call run_refresh before inference batch)")

# COMMAND ----------
# MAGIC %md ## 5. Feature Caching Strategy Summary
# MAGIC
# MAGIC | Layer | Mechanism | Effect |
# MAGIC |---|---|---|
# MAGIC | Spark executor | `spark.databricks.io.cache.enabled=true` | Parquet blocks cached on local SSD |
# MAGIC | DataFrame | `.cache()` on gold_df + feature_df | Avoids recomputing multi-step transforms |
# MAGIC | Delta table | OPTIMIZE + Z-ORDER on customer_id | Co-locates data for key lookups — up to 10× faster joins |
# MAGIC | Online Table | Unity Catalog Online Store | Sub-5ms point lookups during real-time inference |

# COMMAND ----------
# MAGIC %md ## 6. Lakehouse Monitoring — Feature Table

from databricks.sdk.service.catalog import MonitorTimeSeries

try:
    w.quality_monitors.create(
        table_name=feature_table_name,
        output_schema_name=f"{catalog}.{schema}",
        time_series=MonitorTimeSeries(
            timestamp_col="feature_timestamp",
            granularities=["1 day", "1 week"],
        ),
        assets_dir=f"/Shared/mlops-demo/{catalog}/monitoring/features",
    )
    print(f"✓ Lakehouse Monitor created: {feature_table_name}")
except Exception as e:
    if "already exists" in str(e).lower():
        w.quality_monitors.run_refresh(table_name=feature_table_name)
        print(f"✓ Lakehouse Monitor refreshed: {feature_table_name}")
    else:
        raise

print(f"\nFeature table : {feature_table_name}")
print(f"Online table  : {online_table_name}")
print(f"Rows written  : {new_row_count:,}")
