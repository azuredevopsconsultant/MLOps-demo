# Databricks notebook source
# MAGIC %md
# MAGIC # Bronze Layer — Raw Data Ingestion
# MAGIC Uses Databricks Autoloader for incremental ingestion into Delta format.

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema", "mlops_demo")
dbutils.widgets.text("raw_path", "s3://raw-data-bucket/customers/")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")
raw_path = dbutils.widgets.get("raw_path")

from pyspark.sql.functions import current_timestamp, input_file_name

spark.sql(f"CREATE CATALOG IF NOT EXISTS {catalog}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {catalog}.{schema}")

# COMMAND ----------
# MAGIC %md ## Autoloader — Schema inference + evolution

checkpoint_path = f"s3://model-artifacts-bucket/checkpoints/{catalog}/{schema}/bronze_customers"

(
    spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "csv")
    .option("cloudFiles.schemaLocation", checkpoint_path + "/schema")
    .option("cloudFiles.inferColumnTypes", True)
    .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
    .load(raw_path)
    .withColumn("ingestion_timestamp", current_timestamp())
    .withColumn("source_file", input_file_name())
    .writeStream
    .format("delta")
    .option("checkpointLocation", checkpoint_path + "/data")
    .option("mergeSchema", True)
    .trigger(availableNow=True)
    .toTable(f"{catalog}.{schema}.bronze_customers")
)

print(f"✓ Bronze ingestion complete → {catalog}.{schema}.bronze_customers")
