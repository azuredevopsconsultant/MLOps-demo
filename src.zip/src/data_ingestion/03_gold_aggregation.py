# Databricks notebook source
# MAGIC %md
# MAGIC # Gold Layer — ML-Ready Curated Dataset
# MAGIC Aggregations, encodings, and final feature set for model consumption.

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema", "mlops_demo")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")

from pyspark.sql import functions as F

# COMMAND ----------
silver_df = spark.table(f"{catalog}.{schema}.silver_customers")

# spend_12m_avg: pre-aggregate with groupBy — avoids a Window shuffle.
# Window.rowsBetween without orderBy is semantically undefined and forces
# a full shuffle + sort per partition, which is expensive on large tables.
spend_avg = (
    silver_df
    .groupBy("customer_id")
    .agg(F.avg("monthly_spend").alias("spend_12m_avg"))
)

# region_encoded: compute lookup table once, then join — avoids a
# Window.orderBy("region") that sorts the entire dataset.
region_lookup = (
    silver_df
    .select("region").distinct()
    .withColumn("region_encoded", F.monotonically_increasing_id())
)

gold_df = (
    silver_df
    .join(spend_avg,     "customer_id", "left")
    .join(region_lookup, "region",      "left")
    .withColumn("is_high_value", (F.col("monthly_spend") > 100).cast("int"))
    .withColumn("tier_encoded",
        F.when(F.col("product_tier") == "enterprise", 3)
         .when(F.col("product_tier") == "pro", 2)
         .otherwise(1)
    )
    .withColumn("gold_created_at", F.current_timestamp())
)

# MERGE instead of full overwrite — unchanged customer rows are skipped entirely.
gold_df.createOrReplaceTempView("gold_staging")
try:
    spark.sql(f"""
        MERGE INTO {catalog}.{schema}.gold_customers_ml AS target
        USING gold_staging AS source
        ON target.customer_id = source.customer_id
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)
except Exception as e:
    if "table or view not found" in str(e).lower() or "doesn't exist" in str(e).lower():
        gold_df.write.format("delta").saveAsTable(f"{catalog}.{schema}.gold_customers_ml")
    else:
        raise

print(f"✓ Gold layer complete → {catalog}.{schema}.gold_customers_ml")
spark.sql(f"""
    COMMENT ON TABLE {catalog}.{schema}.gold_customers_ml IS
    'ML-ready customer dataset. Curated for churn prediction. Updated daily.'
""")
