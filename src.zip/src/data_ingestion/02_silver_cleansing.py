# Databricks notebook source
# MAGIC %md
# MAGIC # Silver Layer — Data Quality + Cleansing
# MAGIC Uses Delta Live Tables expectations and business rule transformations.

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema", "mlops_demo")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")

from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType

# COMMAND ----------
bronze_df = spark.table(f"{catalog}.{schema}.bronze_customers")

# --- Data quality checks ---
QUALITY_RULES = {
    "valid_customer_id": F.col("customer_id").isNotNull(),
    "valid_age":         F.col("age").between(18, 120),
    "valid_tenure":      F.col("tenure_months") >= 0,
    "valid_spend":       F.col("monthly_spend") >= 0,
}

# Add quality flags
df = bronze_df
for rule_name, rule_expr in QUALITY_RULES.items():
    df = df.withColumn(f"dq_{rule_name}", rule_expr.cast("int"))

df = df.withColumn("dq_overall_pass",
    (F.col("dq_valid_customer_id") == 1) &
    (F.col("dq_valid_age") == 1) &
    (F.col("dq_valid_tenure") == 1) &
    (F.col("dq_valid_spend") == 1)
)

# Log quality stats — single Spark action (was 2 separate .count() calls before)
counts    = df.groupBy("dq_overall_pass").count().collect()
count_map = {row["dq_overall_pass"]: row["count"] for row in counts}
passed    = count_map.get(True, 0)
total     = passed + count_map.get(False, 0)
fail_rate = round((total - passed) / total * 100, 2) if total > 0 else 0.0
print(f"Quality check: {passed}/{total} rows passed ({fail_rate}% failed)")

if fail_rate > 5:
    raise ValueError(f"Data quality failure rate {fail_rate}% exceeds 5% threshold")

# COMMAND ----------
# --- Apply business rules and standardise ---
silver_df = (
    df.filter("dq_overall_pass = true")
    .withColumn("monthly_spend", F.col("monthly_spend").cast(DoubleType()))
    .withColumn("churn_flag", F.when(F.col("status") == "churned", 1).otherwise(0))
    .withColumn("region", F.upper(F.trim(F.col("region"))))
    .withColumn("product_tier", F.lower(F.trim(F.col("product_tier"))))
    .withColumn("processed_at", F.current_timestamp())
    .drop(*[c for c in df.columns if c.startswith("dq_")])
)

# MERGE (upsert) instead of full overwrite — only rewrites changed rows.
# Avoids rewriting the entire table on every run and paying for recompression.
silver_df.createOrReplaceTempView("silver_staging")
try:
    spark.sql(f"""
        MERGE INTO {catalog}.{schema}.silver_customers AS target
        USING silver_staging AS source
        ON target.customer_id = source.customer_id
        WHEN MATCHED THEN UPDATE SET *
        WHEN NOT MATCHED THEN INSERT *
    """)
except Exception as e:
    if "table or view not found" in str(e).lower() or "doesn't exist" in str(e).lower():
        silver_df.write.format("delta").saveAsTable(f"{catalog}.{schema}.silver_customers")
    else:
        raise

print(f"✓ Silver cleansing complete → {catalog}.{schema}.silver_customers ({passed} rows)")
