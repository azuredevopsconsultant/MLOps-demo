# Databricks notebook source
# MAGIC %md
# MAGIC # AutoML Baseline — Databricks AutoML
# MAGIC Uses Databricks AutoML to generate a set of baseline trials and produce a
# MAGIC Python source notebook for each trial run.
# MAGIC
# MAGIC AutoML:
# MAGIC - Runs up to `max_trials` experiments (GBM, LR, Random Forest, XGBoost, etc.)
# MAGIC - Calculates summary statistics and data health warnings automatically
# MAGIC - Produces a **Python notebook** per trial — review, reproduce, and modify the code
# MAGIC - The best trial's run_id is passed forward so it can be compared against the
# MAGIC   champion model, just like any manually trained challenger
# MAGIC
# MAGIC **This notebook is NOT part of the automated CI/CD pipeline.**
# MAGIC Run manually in dev workspace to establish a performance baseline before
# MAGIC committing to the full GBM training pipeline.
# MAGIC
# MAGIC **Cost optimisations:**
# MAGIC - `timeout_minutes=20` caps total wall-clock compute (default is 1 h)
# MAGIC - `max_trials=10` limits trial count — enough for a baseline, not a full HPO sweep
# MAGIC - Runs on the interactive cluster; job cluster not needed for ad-hoc EDA

# COMMAND ----------
dbutils.widgets.text("catalog",         "dev_catalog")
dbutils.widgets.text("schema",          "mlops_demo")
dbutils.widgets.text("max_trials",      "10")
dbutils.widgets.text("timeout_minutes", "20")

catalog          = dbutils.widgets.get("catalog")
schema           = dbutils.widgets.get("schema")
max_trials       = int(dbutils.widgets.get("max_trials"))
timeout_minutes  = int(dbutils.widgets.get("timeout_minutes"))

from databricks import automl
from mlflow import MlflowClient
import mlflow
import pandas as pd

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()

feature_table = f"{catalog}.{schema}.customer_churn_features"

# COMMAND ----------
# MAGIC %md ## 1. Load Training Data

training_df = spark.table(feature_table).drop("feature_timestamp")
print(f"Dataset: {training_df.count():,} rows  ×  {len(training_df.columns)} columns")
print(f"Label distribution:")
training_df.groupBy("label").count().show()

# COMMAND ----------
# MAGIC %md ## 2. Run AutoML Trials
# MAGIC AutoML computes summary statistics on the dataset and logs data health warnings
# MAGIC before running trials.  Each trial produces a source notebook in the experiment.

summary = automl.classify(
    dataset=training_df,
    target_col="label",
    primary_metric="roc_auc",
    timeout_minutes=timeout_minutes,
    max_trials=max_trials,
    experiment_dir=f"/Shared/mlops-demo/{catalog}/automl-baseline",
    pos_label=1,
)

# COMMAND ----------
# MAGIC %md ## 3. Review AutoML Results

print("\n" + "=" * 60)
print("AutoML Baseline Results")
print("=" * 60)
print(f"Best trial run ID : {summary.best_trial.mlflow_run_id}")
print(f"Best model        : {summary.best_trial.model_description}")
print(f"Best AUC          : {summary.best_trial.evaluation_metric_score:.4f}")
print()
print("Data exploration notebook (review for featurisation insights):")
print(f"  {summary.experiment.artifact_location}/data-exploration")
print()
print("All trials:")

trials_df = pd.DataFrame([
    {
        "run_id":     t.mlflow_run_id,
        "model":      t.model_description,
        "auc":        round(t.evaluation_metric_score, 4),
    }
    for t in summary.trials
]).sort_values("auc", ascending=False)

print(trials_df.to_string(index=False))

# COMMAND ----------
# MAGIC %md ## 4. Compare AutoML Best vs Current Champion

full_model_name = f"{catalog}.{schema}.churn_classifier"

try:
    champion_version = client.get_model_version_by_alias(full_model_name, "champion")
    champion_run     = client.get_run(champion_version.run_id)
    champion_auc     = champion_run.data.metrics.get("roc_auc", 0.0)

    automl_auc = summary.best_trial.evaluation_metric_score
    delta      = automl_auc - champion_auc

    print(f"\nAutoML best AUC  : {automl_auc:.4f}")
    print(f"Champion AUC     : {champion_auc:.4f}  (v{champion_version.version})")
    print(f"Delta            : {delta:+.4f}")

    if delta > 0.01:
        print("\n  → AutoML found a significantly better baseline — consider retraining the pipeline")
        print(f"    Best AutoML source notebook: review and adapt to src/model_training/01_train_model.py")
    elif delta > 0:
        print("\n  → Marginal improvement — current pipeline is competitive")
    else:
        print("\n  ✓ Current champion outperforms AutoML baseline — pipeline is well-tuned")

except Exception:
    print("\n  No champion model found — this is the first baseline run")

# COMMAND ----------
# MAGIC %md ## 5. Log Baseline Summary to MLflow

with mlflow.start_run(
    run_id=summary.best_trial.mlflow_run_id,
    nested=False,
):
    mlflow.set_tag("run_type",   "automl_baseline")
    mlflow.set_tag("catalog",    catalog)
    mlflow.set_tag("team",       "mlops")
    mlflow.log_dict(
        trials_df.to_dict(orient="records"),
        "automl_trials_summary.json",
    )

print(f"\n✓ AutoML baseline complete")
print(f"  Experiment : /Shared/mlops-demo/{catalog}/automl-baseline")
print(f"  Best AUC   : {summary.best_trial.evaluation_metric_score:.4f}")
print(f"  Trials     : {len(summary.trials)}")
print()
print("Next steps:")
print("  1. Open the best trial's source notebook to review generated code")
print("  2. Adapt hyperparameters or model class into 01_train_model.py if beneficial")
print("  3. Run 01_train_model.py to create a registered challenger for promotion")
