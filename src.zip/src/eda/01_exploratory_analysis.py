# Databricks notebook source
# MAGIC %md
# MAGIC # Exploratory Data Analysis (EDA)
# MAGIC Interactive, iterative analysis of the customer churn dataset.
# MAGIC Goal: assess whether available data has the potential to solve the business problem
# MAGIC and identify data preparation + featurisation steps for model training.
# MAGIC
# MAGIC **This notebook is NOT part of any automated pipeline.**
# MAGIC Run it manually in the dev workspace when exploring a new data source or
# MAGIC investigating data quality issues.  Results are written to the MLflow experiment
# MAGIC as a reference run so findings are reproducible and shareable.
# MAGIC
# MAGIC **Sections:**
# MAGIC 1. Dataset overview — shape, schema, sample rows
# MAGIC 2. Summary statistics — mean/std/percentiles per feature
# MAGIC 3. Class balance — churn rate and label distribution
# MAGIC 4. Missing value analysis — null rates per column
# MAGIC 5. Feature distributions — histograms + box plots (Pandas profiling)
# MAGIC 6. Correlation analysis — feature-to-label and feature-to-feature
# MAGIC 7. Identify preparation steps — log findings as MLflow artifact

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema",  "mlops_demo")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")

import mlflow
import pandas as pd
import numpy as np
from pyspark.sql import functions as F

mlflow.set_registry_uri("databricks-uc")
mlflow.set_experiment(f"/Shared/mlops-demo/{catalog}/eda-analysis")

feature_table = f"{catalog}.{schema}.customer_churn_features"
gold_table    = f"{catalog}.{schema}.gold_customers_ml"

NUMERIC_COLS  = [
    "tenure_months", "monthly_spend", "spend_12m_avg",
    "num_support_tickets", "num_logins_30d", "days_since_last_login",
]
LABEL_COL = "label"

# COMMAND ----------
# MAGIC %md ## 1. Dataset Overview

df_spark = spark.table(feature_table)
total_rows    = df_spark.count()
total_cols    = len(df_spark.columns)
schema_fields = [(f.name, str(f.dataType)) for f in df_spark.schema.fields]

print(f"Table  : {feature_table}")
print(f"Rows   : {total_rows:,}")
print(f"Columns: {total_cols}")
print()
print("Schema:")
for name, dtype in schema_fields:
    print(f"  {name:35} {dtype}")

df_spark.show(5, truncate=False)

# COMMAND ----------
# MAGIC %md ## 2. Summary Statistics
# MAGIC Single aggregation pass — mean, stddev, min, p25, median, p75, max per numeric column.

agg_exprs = []
for col in NUMERIC_COLS:
    agg_exprs += [
        F.mean(col).alias(f"{col}__mean"),
        F.stddev(col).alias(f"{col}__std"),
        F.min(col).alias(f"{col}__min"),
        F.expr(f"percentile({col}, 0.25)").alias(f"{col}__p25"),
        F.expr(f"percentile({col}, 0.50)").alias(f"{col}__median"),
        F.expr(f"percentile({col}, 0.75)").alias(f"{col}__p75"),
        F.max(col).alias(f"{col}__max"),
    ]

stats_row = df_spark.agg(*agg_exprs).collect()[0].asDict()

print(f"\n{'Feature':35} {'Mean':>10} {'Std':>10} {'Min':>8} {'P25':>8} {'Median':>8} {'P75':>8} {'Max':>8}")
print("-" * 100)
for col in NUMERIC_COLS:
    print(
        f"  {col:33} "
        f"{stats_row[f'{col}__mean']:10.2f} "
        f"{stats_row[f'{col}__std']:10.2f} "
        f"{stats_row[f'{col}__min']:8.1f} "
        f"{stats_row[f'{col}__p25']:8.1f} "
        f"{stats_row[f'{col}__median']:8.1f} "
        f"{stats_row[f'{col}__p75']:8.1f} "
        f"{stats_row[f'{col}__max']:8.1f}"
    )

# COMMAND ----------
# MAGIC %md ## 3. Class Balance — Churn Rate and Label Distribution

label_counts = (
    df_spark.groupBy(LABEL_COL)
    .agg(F.count("*").alias("count"))
    .orderBy(LABEL_COL)
    .collect()
)

print("\nLabel distribution:")
for row in label_counts:
    pct = row["count"] / total_rows * 100
    bar = "█" * int(pct / 2)
    print(f"  label={row[LABEL_COL]}  {row['count']:7,}  ({pct:.1f}%)  {bar}")

churn_rate = next(r["count"] for r in label_counts if r[LABEL_COL] == 1) / total_rows
print(f"\nChurn rate: {churn_rate:.2%}")

if churn_rate < 0.05:
    print("  ⚠️  Highly imbalanced — consider SMOTE, class_weight='balanced', or threshold tuning")
elif churn_rate > 0.40:
    print("  ⚠️  Churn rate unusually high — check data pipeline for label leakage")
else:
    print("  ✓ Class balance acceptable for binary classification")

# COMMAND ----------
# MAGIC %md ## 4. Missing Value Analysis

null_exprs = [
    (F.sum(F.col(c).isNull().cast("int")) / total_rows * 100).alias(c)
    for c in df_spark.columns
]
null_rates = df_spark.agg(*null_exprs).collect()[0].asDict()

print("\nNull rate per column:")
has_nulls = False
for col, rate in sorted(null_rates.items(), key=lambda x: -x[1]):
    if rate > 0:
        flag = "⚠️  ACTION NEEDED" if rate > 2 else "INFO"
        print(f"  {col:40} {rate:.2f}%  [{flag}]")
        has_nulls = True

if not has_nulls:
    print("  ✓ No missing values detected")

# COMMAND ----------
# MAGIC %md ## 5. Feature–Label Correlation
# MAGIC Point-biserial correlation (numeric feature vs binary label).
# MAGIC High absolute values indicate predictive features.

df_pd = df_spark.select(NUMERIC_COLS + [LABEL_COL]).sample(fraction=0.30, seed=42).toPandas()

from scipy import stats as scipy_stats

print("\nFeature–label correlation (point-biserial):")
correlations = {}
for col in NUMERIC_COLS:
    corr, pval = scipy_stats.pointbiserialr(df_pd[col].fillna(0), df_pd[LABEL_COL])
    signal = "STRONG" if abs(corr) > 0.15 else ("MODERATE" if abs(corr) > 0.07 else "WEAK")
    print(f"  {col:35} r={corr:+.3f}  p={pval:.3e}  [{signal}]")
    correlations[col] = round(float(corr), 4)

# Feature–feature correlation matrix (pandas)
corr_matrix = df_pd[NUMERIC_COLS].corr().round(3)
print("\nFeature–feature correlation matrix (|r| > 0.5 = potential collinearity):")
high_corr = [
    (c1, c2, corr_matrix.loc[c1, c2])
    for i, c1 in enumerate(NUMERIC_COLS)
    for c2 in NUMERIC_COLS[i+1:]
    if abs(corr_matrix.loc[c1, c2]) > 0.5
]
for c1, c2, r in high_corr:
    print(f"  {c1} ↔ {c2}  r={r:+.3f}  ⚠️  consider dropping one")
if not high_corr:
    print("  ✓ No high collinearity detected")

# COMMAND ----------
# MAGIC %md ## 6. Log EDA Findings to MLflow
# MAGIC Records findings as an MLflow run so results are reproducible and traceable.

import json as _json

eda_findings = {
    "dataset": {
        "table":       feature_table,
        "total_rows":  total_rows,
        "total_cols":  total_cols,
        "churn_rate":  round(churn_rate, 4),
        "class_balance": "acceptable" if 0.05 <= churn_rate <= 0.40 else "imbalanced",
    },
    "null_rates":    {k: round(v, 4) for k, v in null_rates.items() if v > 0},
    "correlations":  correlations,
    "high_collinearity": [{"f1": c1, "f2": c2, "r": round(r, 3)} for c1, c2, r in high_corr],
    "recommended_prep_steps": [
        "StandardScaler on numeric features (vary in scale)",
        "Handle class imbalance: class_weight='balanced'" if churn_rate < 0.10 else "Class balance OK",
        "Drop collinear feature pairs if any" if high_corr else "No collinearity action needed",
    ],
}

with mlflow.start_run(run_name="eda_findings"):
    mlflow.log_metric("total_rows",   total_rows)
    mlflow.log_metric("churn_rate",   churn_rate)
    mlflow.log_metric("null_col_count", sum(1 for v in null_rates.values() if v > 0))
    mlflow.log_dict(eda_findings, "eda_findings.json")
    mlflow.log_dict(corr_matrix.to_dict(), "feature_correlation_matrix.json")

print("\n✓ EDA findings logged to MLflow experiment")
print(f"  Experiment: /Shared/mlops-demo/{catalog}/eda-analysis")
print(f"\nRecommended preparation steps:")
for step in eda_findings["recommended_prep_steps"]:
    print(f"  • {step}")
