# Databricks notebook source
# MAGIC %md
# MAGIC # Model & Data Monitoring — Lakehouse Monitoring
# MAGIC Tracks prediction drift, feature drift, **concept drift**, and model performance over time.
# MAGIC Runs daily as a scheduled Databricks Job and raises alerts on degradation.
# MAGIC
# MAGIC **Level 3 additions vs previous version:**
# MAGIC - **Concept drift (outcome drift):** detects when actual label distribution shifts,
# MAGIC   not just input features — catches the case where the world has changed
# MAGIC - **Population Stability Index (PSI):** industry-standard complement to KL divergence
# MAGIC - **Trend-based alerting:** 7-day rolling avg vs 30-day baseline detects drift
# MAGIC   trending toward a threshold before it crosses it
# MAGIC - **Sustained-failover alert:** raises alert if serving has been on previous champion
# MAGIC   for > 24h (failover silently masking a live issue)
# MAGIC
# MAGIC **Cost optimisations (unchanged):**
# MAGIC - Single-node spot cluster — no distributed compute needed
# MAGIC - All column stats in **2 Spark actions** (not 12) — one per window
# MAGIC - DataFrames cached and unpersisted
# MAGIC - Partition-pruned Delta reads using date literals

# COMMAND ----------
dbutils.widgets.text("catalog",              "dev_catalog")
dbutils.widgets.text("schema",               "mlops_demo")
dbutils.widgets.text("model_name",           "churn_classifier")
dbutils.widgets.text("drift_threshold",      "0.10")
dbutils.widgets.text("psi_threshold",        "0.20")   # PSI: >0.1 moderate, >0.2 severe
dbutils.widgets.text("trend_window_days",    "7")      # short window for trend comparison
dbutils.widgets.text("perf_threshold",       "0.70")
dbutils.widgets.text("sample_fraction",      "0.30")
dbutils.widgets.text("failover_alert_hours", "24")     # alert if failover active > this long

catalog              = dbutils.widgets.get("catalog")
schema               = dbutils.widgets.get("schema")
model_name           = dbutils.widgets.get("model_name")
drift_threshold      = float(dbutils.widgets.get("drift_threshold"))
psi_threshold        = float(dbutils.widgets.get("psi_threshold"))
trend_window_days    = int(dbutils.widgets.get("trend_window_days"))
perf_threshold       = float(dbutils.widgets.get("perf_threshold"))
sample_fraction      = float(dbutils.widgets.get("sample_fraction"))
failover_alert_hours = float(dbutils.widgets.get("failover_alert_hours"))

from pyspark.sql import SparkSession, functions as F
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.catalog import (
    MonitorTimeSeries,
    MonitorInferenceLogProfileType,
    MonitorInferenceLog,
)
import mlflow
from mlflow import MlflowClient
import pandas as pd
import numpy as np
import json
import urllib.request
import datetime

mlflow.set_registry_uri("databricks-uc")
w      = WorkspaceClient()
client = MlflowClient()
spark  = SparkSession.builder.getOrCreate()

feature_table     = f"{catalog}.{schema}.customer_churn_features"
predictions_table = f"{catalog}.{schema}.churn_predictions"
full_model_name   = f"{catalog}.{schema}.{model_name}"

NUMERIC_COLS = [
    "tenure_months", "monthly_spend", "spend_12m_avg",
    "num_support_tickets", "num_logins_30d", "days_since_last_login",
]

N_BINS    = 20
QUANTILES = [i / N_BINS for i in range(N_BINS + 1)]

# COMMAND ----------
# MAGIC %md ## 1. Lakehouse Monitoring — Feature Table & Inference Log

for table, kwargs in [
    (feature_table, dict(
        time_series=MonitorTimeSeries(
            timestamp_col="feature_timestamp",
            granularities=["1 day", "1 week"],
        ),
        assets_dir=f"/Shared/mlops-demo/{catalog}/monitoring/features",
    )),
    (predictions_table, dict(
        inference_log=MonitorInferenceLog(
            problem_type=MonitorInferenceLogProfileType.CLASSIFICATION,
            prediction_col="churn_probability",
            timestamp_col="scored_at",
            model_id_col="model_uri",
        ),
        assets_dir=f"/Shared/mlops-demo/{catalog}/monitoring/predictions",
    )),
]:
    try:
        w.quality_monitors.create(
            table_name=table,
            output_schema_name=f"{catalog}.{schema}",
            **kwargs,
        )
        print(f"✓ Monitor created: {table}")
    except Exception as e:
        if "already exists" in str(e).lower():
            w.quality_monitors.run_refresh(table_name=table)
            print(f"✓ Monitor refreshed: {table}")
        else:
            raise

# COMMAND ----------
# MAGIC %md ## 2. Feature Drift Detection — KL Divergence + PSI
# MAGIC
# MAGIC **PSI (Population Stability Index)** is the industry standard for input monitoring:
# MAGIC - PSI < 0.10: no significant change
# MAGIC - 0.10 ≤ PSI < 0.20: moderate change — investigate
# MAGIC - PSI ≥ 0.20: severe shift — likely requires model retraining
# MAGIC
# MAGIC Both KL and PSI computed in the same 2 Spark actions as before (no extra cost).

def _compute_kl_psi(ref_bins: list, today_bins: list) -> tuple[float, float]:
    r = np.array(ref_bins,   dtype=float)
    t = np.array(today_bins, dtype=float)
    if len(r) < 2 or len(t) < 2:
        return 0.0, 0.0
    p = np.diff(r); p = np.abs(p) + 1e-10; p /= p.sum()
    q = np.diff(t); q = np.abs(q) + 1e-10; q /= q.sum()
    kl  = float(np.sum(p * np.log(p / q)))
    psi = float(np.sum((q - p) * np.log((q + 1e-10) / (p + 1e-10))))
    return kl, psi

today_date = F.current_date()
ref_date   = F.date_sub(today_date, 30)
trend_date = F.date_sub(today_date, trend_window_days)

today_df = (
    spark.table(feature_table)
    .filter(F.to_date("feature_timestamp") == today_date)
    .select(NUMERIC_COLS).dropna()
    .sample(fraction=sample_fraction, seed=42).cache()
)
ref_df = (
    spark.table(feature_table)
    .filter(F.to_date("feature_timestamp") == ref_date)
    .select(NUMERIC_COLS).dropna()
    .sample(fraction=sample_fraction, seed=42).cache()
)

agg_exprs         = [F.approx_percentile(c, QUANTILES, accuracy=1000).alias(c) for c in NUMERIC_COLS]
today_quantiles   = today_df.agg(*agg_exprs).collect()[0]
ref_quantiles     = ref_df.agg(*agg_exprs).collect()[0]

today_df.unpersist()
ref_df.unpersist()

drift_alerts = []
drift_metrics = {}

print("\n── Feature Drift (KL + PSI) ──")
for col in NUMERIC_COLS:
    kl, psi = _compute_kl_psi(ref_quantiles[col], today_quantiles[col])
    kl_status  = "DRIFT"  if kl  > drift_threshold else "OK"
    psi_status = "SEVERE" if psi > psi_threshold else ("MODERATE" if psi > 0.10 else "OK")
    print(f"  {col:30}  KL={kl:.4f} [{kl_status}]  PSI={psi:.4f} [{psi_status}]")
    drift_metrics[col] = {"kl": kl, "psi": psi}
    if kl > drift_threshold or psi > psi_threshold:
        drift_alerts.append(f"{col} (KL={kl:.4f}, PSI={psi:.4f})")

# COMMAND ----------
# MAGIC %md ## 3. Trend-Based Feature Drift Alert
# MAGIC Compare 7-day window vs 30-day baseline.
# MAGIC Catches features *trending toward* the threshold before crossing it.
# MAGIC No extra Spark actions — reuses same quantile pattern.

trend_df = (
    spark.table(feature_table)
    .filter(
        (F.to_date("feature_timestamp") >= trend_date) &
        (F.to_date("feature_timestamp") < today_date)
    )
    .select(NUMERIC_COLS).dropna()
    .sample(fraction=sample_fraction, seed=42).cache()
)
trend_quantiles = trend_df.agg(*agg_exprs).collect()[0]
trend_df.unpersist()

TREND_WARN_THRESHOLD = drift_threshold * 0.7  # warn at 70% of threshold (trending alert)

print("\n── Trend Alert (7-day vs 30-day) ──")
for col in NUMERIC_COLS:
    kl_trend, psi_trend = _compute_kl_psi(ref_quantiles[col], trend_quantiles[col])
    if kl_trend > TREND_WARN_THRESHOLD:
        msg = f"TRENDING: {col} 7d-KL={kl_trend:.4f} (warn at {TREND_WARN_THRESHOLD:.2f}, alert at {drift_threshold:.2f})"
        print(f"  ⚠ {msg}")
        drift_alerts.append(msg)
    else:
        print(f"  {col:30}  7d-KL={kl_trend:.4f}  [STABLE]")

# COMMAND ----------
# MAGIC %md ## 4. Concept Drift — Outcome / Label Distribution Drift
# MAGIC
# MAGIC **Why concept drift matters:** Covariate drift (feature changes) is a leading indicator.
# MAGIC Concept drift (label changes) is a lagging indicator — the actual relationship between
# MAGIC features and outcomes has changed. This requires immediate retraining.
# MAGIC
# MAGIC Sources:
# MAGIC - **Predicted churn rate trend:** if model is predicting more/less churn over time,
# MAGIC   the population or the decision boundary has shifted
# MAGIC - **Actual churn rate** (from `model_performance_actuals` if available): gold standard

concept_drift_alerts = []

print("\n── Concept Drift (Predicted Label Distribution) ──")
try:
    pred_stats = spark.sql(f"""
        SELECT
            CAST(scored_at AS DATE)                          AS scored_date,
            AVG(churn_probability)                           AS avg_churn_prob,
            SUM(CAST(churn_label = 1 AS INT)) / COUNT(*)    AS predicted_positive_rate,
            COUNT(*)                                         AS n_predictions
        FROM {predictions_table}
        WHERE scored_at >= current_date() - INTERVAL {30 + trend_window_days} DAYS
        GROUP BY 1
        ORDER BY 1
    """).toPandas()

    if not pred_stats.empty and len(pred_stats) >= 7:
        # Baseline: 30-day average positive prediction rate
        baseline_rate = pred_stats[pred_stats["scored_date"] <= (
            pd.Timestamp.today() - pd.Timedelta(days=trend_window_days)
        )]["predicted_positive_rate"].mean()

        # Recent: last 7-day average
        recent_rate = pred_stats.tail(trend_window_days)["predicted_positive_rate"].mean()

        rate_shift = abs(recent_rate - baseline_rate)
        CONCEPT_DRIFT_THRESHOLD = 0.05  # 5 percentage point shift in predicted positive rate

        print(f"  Baseline positive rate (30d avg): {baseline_rate:.3f}")
        print(f"  Recent positive rate  ({trend_window_days}d avg):  {recent_rate:.3f}")
        print(f"  Shift:                           {rate_shift:.3f}  [{'CONCEPT DRIFT' if rate_shift > CONCEPT_DRIFT_THRESHOLD else 'OK'}]")

        if rate_shift > CONCEPT_DRIFT_THRESHOLD:
            direction = "UP" if recent_rate > baseline_rate else "DOWN"
            concept_drift_alerts.append(
                f"CONCEPT_DRIFT: predicted positive rate shifted {direction} "
                f"by {rate_shift:.3f} ({baseline_rate:.3f} → {recent_rate:.3f})"
            )
    else:
        print("  Insufficient prediction history for concept drift analysis")

except Exception as e:
    print(f"  Concept drift check skipped: {e}")

# COMMAND ----------
# MAGIC %md ## 4b. Actual Label Drift (from ground truth feedback loop)
# MAGIC If `model_performance_actuals` exists, compare actual positive rate vs baseline.

print("\n── Actual Label Drift (Ground Truth) ──")
try:
    actual_stats = spark.sql(f"""
        SELECT
            AVG(actual_positive_rate) AS recent_actual_rate
        FROM {catalog}.{schema}.model_performance_actuals
        WHERE scored_date >= current_date() - {trend_window_days}
    """).collect()

    baseline_actual = spark.sql(f"""
        SELECT AVG(actual_positive_rate) AS baseline_actual_rate
        FROM {catalog}.{schema}.model_performance_actuals
        WHERE scored_date >= current_date() - 30
          AND scored_date < current_date() - {trend_window_days}
    """).collect()

    if actual_stats and baseline_actual and actual_stats[0]["recent_actual_rate"] is not None:
        recent_actual   = float(actual_stats[0]["recent_actual_rate"])
        baseline_actual = float(baseline_actual[0]["baseline_actual_rate"] or 0.0)
        actual_shift    = abs(recent_actual - baseline_actual)
        ACTUAL_DRIFT_THRESHOLD = 0.05

        print(f"  Baseline actual rate (30d): {baseline_actual:.3f}")
        print(f"  Recent actual rate ({trend_window_days}d):  {recent_actual:.3f}")
        print(f"  Shift:                      {actual_shift:.3f}  [{'CONCEPT DRIFT' if actual_shift > ACTUAL_DRIFT_THRESHOLD else 'OK'}]")

        if actual_shift > ACTUAL_DRIFT_THRESHOLD:
            concept_drift_alerts.append(
                f"ACTUAL_LABEL_DRIFT: actual positive rate shifted "
                f"{abs(recent_actual - baseline_actual):.3f}"
            )
    else:
        print("  No actual outcome data yet — ground truth loop not yet populated")
except Exception:
    print("  model_performance_actuals table not available — skipping actual label drift")

# COMMAND ----------
# MAGIC %md ## 5. Champion Model Performance Check

champion_version_obj = client.get_model_version_by_alias(full_model_name, "champion")
champion_run         = client.get_run(champion_version_obj.run_id)
champion_auc         = champion_run.data.metrics.get("roc_auc", 0.0)

print(f"\nChampion: {full_model_name} v{champion_version_obj.version}  AUC={champion_auc:.4f}")

perf_alerts = []
if champion_auc < perf_threshold:
    perf_alerts.append(f"Champion AUC {champion_auc:.4f} below threshold {perf_threshold}")

# COMMAND ----------
# MAGIC %md ## 6. Sustained-Failover Alert
# MAGIC If the serving endpoint is running on the *previous* champion (failover) for > failover_alert_hours,
# MAGIC something is structurally wrong — the new challenger failed or the canary was never resolved.

print("\n── Sustained Failover Check ──")
try:
    endpoint = w.serving_endpoints.get(name=f"churn-classifier-{catalog.replace('_catalog','')}")
    routes   = endpoint.config.traffic_config.routes if endpoint.config.traffic_config else []

    # Check if there is NO challenger route (meaning we are 100% on champion = possible failover)
    has_challenger = any(r.served_model_name.startswith("challenger-v") for r in routes)

    if not has_challenger:
        # Check when the last canary deployment attempt was
        last_canary = spark.sql(f"""
            SELECT MAX(trigger_timestamp) AS last_canary_ts
            FROM {catalog}.{schema}.retraining_trigger_log
            WHERE trigger_reason LIKE 'canary_deploy_v%'
        """).collect()

        if last_canary and last_canary[0]["last_canary_ts"] is not None:
            hours_since = (datetime.datetime.utcnow() - last_canary[0]["last_canary_ts"]).total_seconds() / 3600
            print(f"  No challenger active. Hours since last canary attempt: {hours_since:.1f}h")
            if hours_since > failover_alert_hours:
                concept_drift_alerts.append(
                    f"SUSTAINED_FAILOVER: No challenger active for {hours_since:.1f}h "
                    f"after canary deployment — canary may have rolled back silently"
                )
        else:
            print("  No challenger active and no canary history — first deploy or manual state")
    else:
        print("  Challenger route active — canary in progress, no failover concern")

except Exception as e:
    print(f"  Sustained failover check skipped: {e}")

# COMMAND ----------
# MAGIC %md ## 7. Data Freshness Check

from datetime import timezone

FRESHNESS_TABLES = {
    f"{catalog}.{schema}.bronze_customers":          ("ingestion_timestamp", 25),
    f"{catalog}.{schema}.silver_customers":          ("processed_at", 25),
    f"{catalog}.{schema}.customer_churn_features":   ("feature_timestamp", 25),
    predictions_table:                               ("scored_at", 25),
}

quality_alerts = []
now_utc = datetime.datetime.now(timezone.utc)

for table, (ts_col, max_age_hours) in FRESHNESS_TABLES.items():
    try:
        row = spark.sql(
            f"SELECT MAX({ts_col}) AS latest, COUNT(*) AS row_count FROM {table}"
        ).collect()[0]
        if row["latest"] is None:
            quality_alerts.append(f"FRESHNESS: {table} is EMPTY")
            continue
        age_hours = (now_utc - row["latest"].astimezone(timezone.utc).replace(tzinfo=timezone.utc)).total_seconds() / 3600
        status = "STALE" if age_hours > max_age_hours else "OK"
        print(f"  {table.split('.')[-1]:35} age={age_hours:.1f}h  rows={row['row_count']:,}  [{status}]")
        if age_hours > max_age_hours:
            quality_alerts.append(f"FRESHNESS: {table} is {age_hours:.1f}h stale (max {max_age_hours}h)")
    except Exception as e:
        quality_alerts.append(f"FRESHNESS: {table} query failed — {e}")

# COMMAND ----------
# MAGIC %md ## 8. Data Completeness Check

COMPLETENESS_CHECKS = {
    f"{catalog}.{schema}.silver_customers": [
        "customer_id", "churn_flag", "tenure_months", "monthly_spend",
    ],
    feature_table: [
        "customer_id", "tenure_months", "monthly_spend", "spend_12m_avg", "label",
    ],
}
NULL_THRESHOLD = 0.02

for table, required_cols in COMPLETENESS_CHECKS.items():
    null_exprs = [F.mean(F.col(c).isNull().cast("double")).alias(c) for c in required_cols]
    null_rates = spark.table(table).agg(*null_exprs).collect()[0]
    for col in required_cols:
        rate   = null_rates[col] or 0.0
        status = "INCOMPLETE" if rate > NULL_THRESHOLD else "OK"
        if rate > NULL_THRESHOLD:
            quality_alerts.append(f"COMPLETENESS: {table}.{col} null rate {rate*100:.1f}% (>{NULL_THRESHOLD*100}%)")

# COMMAND ----------
# MAGIC %md ## 9. Prediction Distribution Drift (KL + PSI)

today_date_str = F.current_date()
ref_date_str   = F.date_sub(today_date_str, 30)

pred_today = (
    spark.table(predictions_table)
    .filter(F.to_date("scored_at") == today_date_str)
    .select("churn_probability").dropna()
    .sample(fraction=sample_fraction, seed=42).cache()
)
pred_ref = (
    spark.table(predictions_table)
    .filter(F.to_date("scored_at") == ref_date_str)
    .select("churn_probability").dropna()
    .sample(fraction=sample_fraction, seed=42).cache()
)

pred_today_q = pred_today.agg(F.approx_percentile("churn_probability", QUANTILES, 1000).alias("q")).collect()[0]["q"]
pred_ref_q   = pred_ref.agg(F.approx_percentile("churn_probability",  QUANTILES, 1000).alias("q")).collect()[0]["q"]
pred_today.unpersist()
pred_ref.unpersist()

if pred_today_q and pred_ref_q and len(pred_today_q) > 1:
    pred_kl, pred_psi = _compute_kl_psi(pred_ref_q, pred_today_q)
    kl_status  = "DRIFT"  if pred_kl  > drift_threshold else "OK"
    psi_status = "SEVERE" if pred_psi > psi_threshold   else ("MODERATE" if pred_psi > 0.10 else "OK")
    print(f"\n  churn_probability  KL={pred_kl:.4f} [{kl_status}]  PSI={pred_psi:.4f} [{psi_status}]")
    if pred_kl > drift_threshold or pred_psi > psi_threshold:
        drift_alerts.append(f"PREDICTION_DRIFT churn_probability (KL={pred_kl:.4f}, PSI={pred_psi:.4f})")

# COMMAND ----------
# MAGIC %md ## 10. Write Monitoring Summary to Delta

all_alerts = quality_alerts + drift_alerts + concept_drift_alerts + perf_alerts

(
    spark.createDataFrame(pd.DataFrame([{
        "catalog":            catalog,
        "model_name":         model_name,
        "model_version":      champion_version_obj.version,
        "champion_auc":       champion_auc,
        "drift_columns":      ",".join(drift_alerts)         if drift_alerts         else "none",
        "concept_drift":      ",".join(concept_drift_alerts) if concept_drift_alerts else "none",
        "drift_alert":        len(drift_alerts) > 0,
        "concept_drift_alert":len(concept_drift_alerts) > 0,
        "perf_alert":         len(perf_alerts) > 0,
        "quality_alert":      len(quality_alerts) > 0,
        "monitored_at":       pd.Timestamp.utcnow(),
    }]))
    .write.format("delta").mode("append")
    .option("mergeSchema", True)
    .saveAsTable(f"{catalog}.{schema}.model_monitoring_log")
)
print(f"✓ Monitoring log written → {catalog}.{schema}.model_monitoring_log")

# COMMAND ----------
# MAGIC %md ## 11. Slack Alerts

def _send_slack(webhook_url: str, message: str, env: str) -> None:
    payload = json.dumps({
        "text": f":warning: *MLOps Alert [{env.upper()}]*\n{message}",
        "username": "MLOps Monitor",
    }).encode("utf-8")
    req = urllib.request.Request(
        webhook_url, data=payload,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)

try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
except Exception:
    slack_url = None

if all_alerts:
    alert_msg = "\n".join(f"  • {a}" for a in all_alerts)
    print(f"\n⚠  MONITORING ALERTS:\n{alert_msg}")
    if slack_url:
        _send_slack(slack_url, alert_msg, catalog.split("_")[0])
        print("✓ Slack notification sent")
    raise Exception(f"Monitoring alerts detected:\n{alert_msg}")
else:
    print("\n✓ All monitoring checks passed — covariate drift, concept drift, freshness, completeness, performance all OK")
