# Databricks notebook source
# MAGIC %md
# MAGIC # Model Serving Endpoint — Health, Latency & Failover
# MAGIC Probes the churn-classifier serving endpoint every hour:
# MAGIC   1. State check — READY / NOT_READY
# MAGIC   2. Synthetic latency probe — p50 / p95 via timed scoring requests
# MAGIC   3. Request/response pattern stats from system.serving.endpoint_requests
# MAGIC   4. Automatic failover to previous champion version if thresholds breached
# MAGIC
# MAGIC **Cost optimisations applied:**
# MAGIC - Single-node SPOT cluster — no Spark distributed compute
# MAGIC - System table query uses partition pruning on `request_time`
# MAGIC - Failover triggered only when strictly necessary (avoids unnecessary redeployments)

# COMMAND ----------
dbutils.widgets.text("catalog",              "dev_catalog")
dbutils.widgets.text("schema",               "mlops_demo")
dbutils.widgets.text("model_name",           "churn_classifier")
dbutils.widgets.text("max_latency_p95_ms",   "500")   # alert + failover if p95 > 500ms
dbutils.widgets.text("max_error_rate",       "0.05")  # alert + failover if error rate > 5%
dbutils.widgets.text("probe_requests",       "10")    # synthetic health probe request count

catalog            = dbutils.widgets.get("catalog")
schema             = dbutils.widgets.get("schema")
model_name         = dbutils.widgets.get("model_name")
max_latency_p95_ms = float(dbutils.widgets.get("max_latency_p95_ms"))
max_error_rate     = float(dbutils.widgets.get("max_error_rate"))
probe_requests     = int(dbutils.widgets.get("probe_requests"))

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import (
    EndpointStateReady,
    ServedModelInput,
    TrafficConfig,
    Route,
)
from mlflow import MlflowClient
from pyspark.sql import SparkSession, functions as F
import time, json, urllib.request, statistics, pandas as pd

mlflow_client = MlflowClient()
mlflow_client._registry_uri = "databricks-uc"
spark         = SparkSession.builder.getOrCreate()
w             = WorkspaceClient()

endpoint_name  = f"churn-classifier-{catalog.split('_')[0]}"
full_model_name = f"{catalog}.{schema}.{model_name}"

# COMMAND ----------
# MAGIC %md ## 1. Endpoint State Check

endpoint = w.serving_endpoints.get(name=endpoint_name)
state    = endpoint.state

print(f"Endpoint : {endpoint_name}")
print(f"  Ready  : {state.ready}")
print(f"  Config : {state.config_update}")

serving_alerts = []

if state.ready != EndpointStateReady.READY:
    serving_alerts.append(
        f"ENDPOINT NOT READY: {endpoint_name} state={state.ready}"
    )

# COMMAND ----------
# MAGIC %md ## 2. Latency Probe — Synthetic Scoring Requests
# MAGIC Sends `probe_requests` minimal scoring requests and measures wall-clock latency.
# MAGIC Uses the workspace token from the SDK context — no extra credentials needed.

token  = w.config.token
host   = w.config.host.rstrip("/")
score_url = f"{host}/serving-endpoints/{endpoint_name}/invocations"

sample_payload = json.dumps({
    "dataframe_records": [
        {
            "customer_id":         f"probe_{i}",
            "tenure_months":       24,
            "monthly_spend":       50.0,
            "spend_12m_avg":       48.5,
            "is_high_value":       1,
            "region_encoded":      2,
            "tier_encoded":        1,
            "num_support_tickets": 1,
            "num_logins_30d":      12,
            "days_since_last_login": 3,
        }
        for i in range(probe_requests)
    ]
}).encode("utf-8")

latencies_ms = []
errors       = 0

for _ in range(probe_requests):
    req = urllib.request.Request(
        score_url,
        data=sample_payload,
        headers={
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {token}",
        },
        method="POST",
    )
    t0 = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            resp.read()                               # ensure full response received
        latencies_ms.append((time.perf_counter() - t0) * 1000)
    except Exception as e:
        errors += 1
        print(f"  Probe error: {e}")

if latencies_ms:
    sorted_lats  = sorted(latencies_ms)
    p50_ms = statistics.median(latencies_ms)
    p95_ms = sorted_lats[max(0, int(len(sorted_lats) * 0.95) - 1)]
    print(f"\n  Latency probe ({probe_requests} requests)")
    print(f"    p50 = {p50_ms:.1f}ms   p95 = {p95_ms:.1f}ms   errors = {errors}")

    if p95_ms > max_latency_p95_ms:
        serving_alerts.append(
            f"HIGH LATENCY: {endpoint_name} p95={p95_ms:.0f}ms (threshold {max_latency_p95_ms:.0f}ms)"
        )
    error_rate = errors / probe_requests
    if error_rate > max_error_rate:
        serving_alerts.append(
            f"HIGH ERROR RATE: {endpoint_name} {error_rate*100:.0f}% errors (threshold {max_error_rate*100:.0f}%)"
        )
else:
    serving_alerts.append(f"PROBE FAILED: {endpoint_name} — all {probe_requests} probe requests failed")
    p50_ms = p95_ms = 0.0
    error_rate = 1.0

# COMMAND ----------
# MAGIC %md ## 3. Request / Response Patterns — Last 24 Hours
# MAGIC Queries system.serving.endpoint_requests (partition-pruned by request_time).

try:
    req_stats = spark.sql(f"""
        SELECT
            DATE_TRUNC('hour', request_time)  AS hour_bucket,
            COUNT(*)                           AS total_requests,
            ROUND(AVG(execution_time_ms), 0)   AS avg_latency_ms,
            SUM(CASE WHEN status_code >= 500 THEN 1 ELSE 0 END) AS server_errors,
            SUM(CASE WHEN status_code >= 400 THEN 1 ELSE 0 END) AS client_errors
        FROM system.serving.endpoint_requests
        WHERE endpoint_name = '{endpoint_name}'
          AND request_time >= TIMESTAMPADD(HOUR, -24, CURRENT_TIMESTAMP())
        GROUP BY 1
        ORDER BY 1 DESC
    """)
    req_stats.show(24, truncate=False)
    request_pattern_available = True
except Exception as e:
    print(f"  system.serving.endpoint_requests not available: {e}")
    request_pattern_available = False

# COMMAND ----------
# MAGIC %md ## 4. Write Serving Health Log

health_rows = [{
    "catalog":        catalog,
    "endpoint_name":  endpoint_name,
    "endpoint_ready": str(state.ready),
    "probe_p50_ms":   round(p50_ms,   1),
    "probe_p95_ms":   round(p95_ms,   1),
    "probe_error_rate": round(error_rate, 4),
    "serving_alert":  len(serving_alerts) > 0,
    "monitored_at":   pd.Timestamp.utcnow(),
}]

(
    spark.createDataFrame(pd.DataFrame(health_rows))
    .write.format("delta").mode("append")
    .option("mergeSchema", True)
    .saveAsTable(f"{catalog}.{schema}.serving_health_log")
)
print(f"✓ Serving health log written → {catalog}.{schema}.serving_health_log")

# COMMAND ----------
# MAGIC %md ## 5. Automatic Failover to Previous Champion
# MAGIC If latency or error rate thresholds are breached, look up the second-most-recent
# MAGIC model version tagged as champion and redeploy the endpoint to that version.
# MAGIC This avoids a full retrain and recovers service within minutes.

FAILOVER_TRIGGERS = {"HIGH LATENCY", "HIGH ERROR RATE", "ENDPOINT NOT READY"}
needs_failover = any(
    any(trigger in alert for trigger in FAILOVER_TRIGGERS)
    for alert in serving_alerts
)

if needs_failover:
    print("\n⚠️  Failover triggered — locating previous champion version...")
    try:
        versions = mlflow_client.search_model_versions(
            filter_string=f"name='{full_model_name}'",
            order_by=["creation_timestamp DESC"],
        )
        champion_versions = [
            v for v in versions
            if v.aliases and "champion" in v.aliases
        ]
        # Current champion is index 0; fall back to most-recent non-champion version
        fallback = (
            champion_versions[1] if len(champion_versions) > 1
            else next((v for v in versions if not (v.aliases and "champion" in v.aliases)), None)
        )

        if fallback:
            print(f"  Redeploying endpoint to version {fallback.version} (fallback champion)")
            w.serving_endpoints.update_config(
                name=endpoint_name,
                served_models=[
                    ServedModelInput(
                        model_name=full_model_name,
                        model_version=fallback.version,
                        workload_size="Small",
                        scale_to_zero_enabled=True,
                    )
                ],
                traffic_config=TrafficConfig(
                    routes=[Route(served_model_name=f"{model_name}-{fallback.version}", traffic_percentage=100)]
                ),
            )
            serving_alerts.append(
                f"FAILOVER EXECUTED: endpoint redeployed to version {fallback.version}"
            )
            print(f"  ✓ Failover complete — endpoint now serving version {fallback.version}")
        else:
            serving_alerts.append("FAILOVER SKIPPED: no previous champion version available")
    except Exception as e:
        serving_alerts.append(f"FAILOVER ERROR: {e}")

# COMMAND ----------
# MAGIC %md ## 6. Alerts

def _send_slack(webhook_url: str, message: str, env: str) -> None:
    payload = json.dumps({
        "text": f":rotating_light: *Serving Alert [{env.upper()}]*\n{message}",
        "username": "MLOps Serving Monitor",
    }).encode("utf-8")
    req = urllib.request.Request(
        webhook_url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)

try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
except Exception:
    slack_url = None

if serving_alerts:
    alert_msg = "\n".join(f"  • {a}" for a in serving_alerts)
    print(f"\n⚠️  SERVING ALERTS:\n{alert_msg}")
    if slack_url:
        _send_slack(slack_url, alert_msg, catalog.split("_")[0])
        print("✓ Slack notification sent")
    # Don't raise if the only alert is the completed failover — service is recovering
    if not all("FAILOVER EXECUTED" in a or "FAILOVER SKIPPED" in a for a in serving_alerts):
        raise Exception(f"Serving endpoint alerts:\n{alert_msg}")
else:
    print(f"\n✓ Endpoint {endpoint_name} healthy — latency and error rate within thresholds")
