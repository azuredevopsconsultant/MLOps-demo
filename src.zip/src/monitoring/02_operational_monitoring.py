# Databricks notebook source
# MAGIC %md
# MAGIC # Operational Monitoring — Pipeline Jobs, Resource Utilisation & Costs
# MAGIC Queries last 7 days of job run history via the Databricks SDK and Unity Catalog
# MAGIC system tables to compute success rates, execution times, and DBU costs.
# MAGIC Sends Slack alerts on failures or cost spikes.
# MAGIC
# MAGIC **Cost optimisations applied:**
# MAGIC - Runs on a single-node SPOT cluster — only SDK + system table SQL, no Spark ETL
# MAGIC - System table queries use partition pruning on `usage_date` (file-skipping)
# MAGIC - All job stats collected in a single pass — no repeated list_runs calls per task

# COMMAND ----------
dbutils.widgets.text("catalog",           "dev_catalog")
dbutils.widgets.text("schema",            "mlops_demo")
dbutils.widgets.text("lookback_days",     "7")
dbutils.widgets.text("max_duration_mins", "120")   # alert if avg job duration exceeds this
dbutils.widgets.text("max_dbu_daily",     "50")    # alert if daily DBU spend exceeds this

catalog          = dbutils.widgets.get("catalog")
schema           = dbutils.widgets.get("schema")
lookback_days    = int(dbutils.widgets.get("lookback_days"))
max_duration     = float(dbutils.widgets.get("max_duration_mins"))
max_dbu_daily    = float(dbutils.widgets.get("max_dbu_daily"))

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import RunResultState, RunLifeCycleState
from pyspark.sql import SparkSession, functions as F
import pandas as pd
import json, urllib.request
from datetime import datetime, timedelta, timezone

spark = SparkSession.builder.getOrCreate()
w     = WorkspaceClient()

cutoff_epoch_ms = int(
    (datetime.now(timezone.utc) - timedelta(days=lookback_days)).timestamp() * 1000
)

# COMMAND ----------
# MAGIC %md ## 1. Job Execution — Success Rates & Duration
# MAGIC Single SDK pass across all jobs: list runs once, aggregate in Python.

job_stats: dict[str, dict] = {}

for job in w.jobs.list():
    job_id   = job.job_id
    job_name = job.settings.name or f"job_{job_id}"
    runs     = list(w.jobs.list_runs(
        job_id=job_id,
        completed_only=True,
        limit=14,             # ~2 weeks at daily cadence
    ))
    recent   = [r for r in runs if (r.start_time or 0) >= cutoff_epoch_ms]
    if not recent:
        continue

    durations_ms = [r.execution_duration for r in recent if r.execution_duration]
    succeeded    = [r for r in recent if r.state and r.state.result_state == RunResultState.SUCCESS]
    failed       = [r for r in recent if r.state and r.state.result_state == RunResultState.FAILED]

    avg_mins   = (sum(durations_ms) / len(durations_ms) / 60_000) if durations_ms else 0.0
    p95_mins   = (sorted(durations_ms)[int(len(durations_ms) * 0.95)] / 60_000) if durations_ms else 0.0
    success_rt = len(succeeded) / len(recent)

    job_stats[job_name] = {
        "job_id":        job_id,
        "runs_checked":  len(recent),
        "success_rate":  round(success_rt, 3),
        "failure_count": len(failed),
        "avg_mins":      round(avg_mins,   2),
        "p95_mins":      round(p95_mins,   2),
        "failed_run_ids": [r.run_id for r in failed],
    }
    print(
        f"  {job_name:50} runs={len(recent):3}  "
        f"success={success_rt*100:.0f}%  avg={avg_mins:.1f}m  p95={p95_mins:.1f}m"
    )

# COMMAND ----------
# MAGIC %md ## 2. DBU Cost Tracking via system.billing.usage
# MAGIC Partition-pruned scan on usage_date — only reads the last N days of Parquet.

cost_df = spark.sql(f"""
    SELECT
        usage_date,
        sku_name,
        ROUND(SUM(usage_quantity), 2)  AS total_dbu,
        ROUND(SUM(list_cost),      2)  AS list_cost_usd
    FROM system.billing.usage
    WHERE usage_date >= DATE_SUB(CURRENT_DATE(), {lookback_days})
      AND billing_origin_product IN ('JOBS', 'MODEL_SERVING')
    GROUP BY usage_date, sku_name
    ORDER BY usage_date DESC, total_dbu DESC
""")

cost_df.show(20, truncate=False)

daily_totals = cost_df.groupBy("usage_date").agg(
    F.round(F.sum("total_dbu"),    2).alias("dbu"),
    F.round(F.sum("list_cost_usd"),2).alias("usd"),
).orderBy(F.desc("usage_date")).collect()

cost_alerts = []
for row in daily_totals[:3]:   # check last 3 days for spikes
    if row["dbu"] > max_dbu_daily:
        cost_alerts.append(
            f"COST SPIKE: {row['usage_date']} used {row['dbu']} DBU "
            f"(${row['usd']:.2f}) — threshold {max_dbu_daily} DBU/day"
        )

# COMMAND ----------
# MAGIC %md ## 3. Write Operational Monitoring Log

op_rows = [
    {
        "catalog":       catalog,
        "job_name":      name,
        "job_id":        str(stats["job_id"]),
        "success_rate":  stats["success_rate"],
        "failure_count": stats["failure_count"],
        "avg_mins":      stats["avg_mins"],
        "p95_mins":      stats["p95_mins"],
        "failed_run_ids": ",".join(str(r) for r in stats["failed_run_ids"]) or "none",
        "monitored_at":  pd.Timestamp.utcnow(),
    }
    for name, stats in job_stats.items()
]

if op_rows:
    (
        spark.createDataFrame(pd.DataFrame(op_rows))
        .write.format("delta").mode("append")
        .option("mergeSchema", True)
        .saveAsTable(f"{catalog}.{schema}.operational_monitoring_log")
    )
    print(f"✓ Operational log written → {catalog}.{schema}.operational_monitoring_log")

# COMMAND ----------
# MAGIC %md ## 4. Alerts — Pipeline Failures, Slow Jobs, Cost Spikes

pipeline_alerts = []

for name, stats in job_stats.items():
    if stats["failure_count"] > 0:
        pipeline_alerts.append(
            f"PIPELINE FAILURE: {name} had {stats['failure_count']} failure(s) "
            f"in last {lookback_days}d — run IDs: {stats['failed_run_ids']}"
        )
    if stats["avg_mins"] > max_duration:
        pipeline_alerts.append(
            f"SLOW JOB: {name} avg duration {stats['avg_mins']}m exceeds {max_duration}m threshold"
        )

all_alerts = pipeline_alerts + cost_alerts

def _send_slack(webhook_url: str, message: str, env: str) -> None:
    payload = json.dumps({
        "text": f":bar_chart: *Operational Alert [{env.upper()}]*\n{message}",
        "username": "MLOps Ops Monitor",
    }).encode("utf-8")
    req = urllib.request.Request(
        webhook_url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)

try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
except Exception:
    slack_url = None

if all_alerts:
    alert_msg = "\n".join(f"  • {a}" for a in all_alerts)
    print(f"\n⚠️  OPERATIONAL ALERTS:\n{alert_msg}")
    if slack_url:
        _send_slack(slack_url, alert_msg, catalog.split("_")[0])
        print("✓ Slack notification sent")
    raise Exception(f"Operational monitoring alerts:\n{alert_msg}")
else:
    print(f"\n✓ All pipeline jobs healthy over last {lookback_days} days — no failures or cost spikes")
