# Databricks notebook source
# MAGIC %md
# MAGIC # Trigger-Based Retraining — Drift & Performance Alerts
# MAGIC Reads the `model_monitoring_log` table written by `01_model_monitoring.py`.
# MAGIC If drift or performance degradation is detected, it automatically triggers
# MAGIC the full `model_training_job` pipeline (train → register → validate → promote).
# MAGIC
# MAGIC **When to run:**
# MAGIC  - Runs daily at 08:00 UTC — immediately after the monitoring job (07:00 UTC)
# MAGIC  - Can also be invoked directly if a SQL Alert fires (see Section 3 below)
# MAGIC
# MAGIC **Drift thresholds (mirrors monitoring_job parameters):**
# MAGIC  - `drift_threshold`   : KL divergence > 0.10 on any feature or prediction column
# MAGIC  - `perf_threshold`    : champion AUC below 0.70
# MAGIC  - `freshness_max_age` : any table stale > 25 h
# MAGIC
# MAGIC **Cost optimisations:**
# MAGIC  - Single-node SPOT m5.large — only SQL reads + SDK job trigger
# MAGIC  - Retraining is only triggered when strictly needed — avoids unnecessary DBU spend

# COMMAND ----------
dbutils.widgets.text("catalog",           "dev_catalog")
dbutils.widgets.text("schema",            "mlops_demo")
dbutils.widgets.text("model_name",        "churn_classifier")
dbutils.widgets.text("drift_threshold",   "0.10")
dbutils.widgets.text("perf_threshold",    "0.70")
dbutils.widgets.text("lookback_hours",    "26")   # check last ~1 day of monitoring runs

catalog          = dbutils.widgets.get("catalog")
schema           = dbutils.widgets.get("schema")
model_name       = dbutils.widgets.get("model_name")
drift_threshold  = float(dbutils.widgets.get("drift_threshold"))
perf_threshold   = float(dbutils.widgets.get("perf_threshold"))
lookback_hours   = int(dbutils.widgets.get("lookback_hours"))

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import RunParameters
from pyspark.sql import SparkSession, functions as F
import json, urllib.request, pandas as pd
from datetime import datetime, timezone

spark = SparkSession.builder.getOrCreate()
w     = WorkspaceClient()

monitoring_log    = f"{catalog}.{schema}.model_monitoring_log"
training_job_name = f"[{catalog.split('_')[0]}] Model Training"   # matches databricks.yml job name pattern

# COMMAND ----------
# MAGIC %md ## 1. Read Monitoring Log — Check Latest Run

latest = spark.sql(f"""
    SELECT
        model_name,
        champion_auc,
        drift_columns,
        drift_alert,
        perf_alert,
        monitored_at
    FROM {monitoring_log}
    WHERE monitored_at >= TIMESTAMPADD(HOUR, -{lookback_hours}, CURRENT_TIMESTAMP())
      AND catalog = '{catalog}'
    ORDER BY monitored_at DESC
    LIMIT 1
""").collect()

if not latest:
    print(f"No monitoring run found in the last {lookback_hours}h — skipping retraining check")
    dbutils.notebook.exit("NO_MONITORING_DATA")

row = latest[0]
drift_alert = bool(row["drift_alert"])
perf_alert  = bool(row["perf_alert"])
champion_auc = float(row["champion_auc"] or 0.0)
drift_cols   = row["drift_columns"] or "none"

print(f"Latest monitoring run  : {row['monitored_at']}")
print(f"  Champion AUC         : {champion_auc:.4f}  ({'BELOW' if perf_alert else 'OK'} threshold {perf_threshold})")
print(f"  Drift detected       : {drift_cols}")
print(f"  Drift alert          : {drift_alert}")
print(f"  Perf alert           : {perf_alert}")

# COMMAND ----------
# MAGIC %md ## 2. Decide Whether to Retrain

needs_retrain = drift_alert or perf_alert
retrain_reason = []

if drift_alert:
    retrain_reason.append(f"feature/prediction drift detected in: {drift_cols}")
if perf_alert:
    retrain_reason.append(f"champion AUC {champion_auc:.4f} below threshold {perf_threshold}")

if not needs_retrain:
    print("\n✓ No retraining needed — model is healthy and data is stable")
    dbutils.notebook.exit("NO_RETRAIN_NEEDED")

reason_str = "; ".join(retrain_reason)
print(f"\n⚠️  Retraining triggered: {reason_str}")

# COMMAND ----------
# MAGIC %md ## 3. SQL Alert Query — Performance-Based Trigger
# MAGIC Create this query as a **Databricks SQL Alert** to get email/Slack notifications
# MAGIC and optionally trigger a webhook that calls the Databricks Jobs API.
# MAGIC
# MAGIC ```sql
# MAGIC -- Alert: model requires retraining
# MAGIC -- Condition: alert_count > 0
# MAGIC SELECT COUNT(*) AS alert_count
# MAGIC FROM <catalog>.mlops_demo.model_monitoring_log
# MAGIC WHERE (drift_alert = TRUE OR perf_alert = TRUE)
# MAGIC   AND monitored_at >= TIMESTAMPADD(HOUR, -26, CURRENT_TIMESTAMP())
# MAGIC ```
# MAGIC
# MAGIC **Setup steps:**
# MAGIC 1. Databricks SQL → Alerts → New Alert
# MAGIC 2. Paste query above (replace `<catalog>` with env catalog)
# MAGIC 3. Condition: `alert_count` IS GREATER THAN `0`
# MAGIC 4. Notifications → Add webhook → Databricks Jobs API run_now URL
# MAGIC 5. Schedule: Every hour (checks last 26h window)

# COMMAND ----------
# MAGIC %md ## 4. Trigger model_training_job via SDK

try:
    training_job = next(
        j for j in w.jobs.list()
        if j.settings and j.settings.name and training_job_name in (j.settings.name or "")
    )
except StopIteration:
    raise RuntimeError(
        f"Could not find training job matching '{training_job_name}'. "
        "Check that the bundle is deployed and job name matches."
    )

run = w.jobs.run_now(
    job_id=training_job.job_id,
    job_parameters={
        "catalog":    catalog,
        "schema":     schema,
        "model_name": model_name,
    },
)

print(f"\n✓ Retraining triggered")
print(f"  Job name : {training_job.settings.name}")
print(f"  Job ID   : {training_job.job_id}")
print(f"  Run ID   : {run.run_id}")
print(f"  Reason   : {reason_str}")

# COMMAND ----------
# MAGIC %md ## 5. Log Retraining Trigger Event

trigger_row = [{
    "catalog":          catalog,
    "model_name":       model_name,
    "trigger_reason":   reason_str,
    "drift_alert":      drift_alert,
    "perf_alert":       perf_alert,
    "champion_auc":     champion_auc,
    "training_job_id":  str(training_job.job_id),
    "training_run_id":  str(run.run_id),
    "triggered_at":     pd.Timestamp.utcnow(),
}]

(
    spark.createDataFrame(pd.DataFrame(trigger_row))
    .write.format("delta").mode("append")
    .option("mergeSchema", True)
    .saveAsTable(f"{catalog}.{schema}.retraining_trigger_log")
)

# Alert via Slack
try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
    payload = json.dumps({
        "text": (
            f":arrows_counterclockwise: *Retraining triggered [{catalog.split('_')[0].upper()}]*\n"
            f"  Reason: {reason_str}\n"
            f"  Job run: {run.run_id}"
        ),
        "username": "MLOps Retraining",
    }).encode("utf-8")
    req = urllib.request.Request(
        slack_url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)
    print("✓ Slack notification sent")
except Exception:
    pass   # slack not configured — non-fatal

dbutils.notebook.exit(f"RETRAIN_TRIGGERED:run_id={run.run_id}")
