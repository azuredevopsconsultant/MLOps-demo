# Databricks notebook source
# MAGIC %md
# MAGIC # Scheduled Retraining — Weekly Full Pipeline
# MAGIC Runs every Monday at 02:00 UTC (off-peak SPOT pricing).
# MAGIC Before triggering training it performs three gate checks:
# MAGIC   1. **Data freshness** — feature table must have been updated within 25 h
# MAGIC   2. **Minimum row count** — must have sufficient training data
# MAGIC   3. **Retraining interval** — skip if a successful run completed < 6 days ago
# MAGIC      (prevents double-retraining when trigger-based already fired)
# MAGIC
# MAGIC If all gates pass it calls `w.jobs.run_now()` on `model_training_job`,
# MAGIC which chains: train → register (AUC gate) → validate → (prod) promote.
# MAGIC
# MAGIC **Cost optimisations:**
# MAGIC  - Gate checks are pure SQL — no Spark compute
# MAGIC  - Single-node SPOT m5.large — only SDK calls after SQL checks
# MAGIC  - Off-peak schedule (Mon 02:00 UTC) gets cheapest SPOT prices

# COMMAND ----------
dbutils.widgets.text("catalog",              "dev_catalog")
dbutils.widgets.text("schema",               "mlops_demo")
dbutils.widgets.text("model_name",           "churn_classifier")
dbutils.widgets.text("min_training_rows",    "1000")
dbutils.widgets.text("freshness_max_age_h",  "25")
dbutils.widgets.text("min_retrain_interval_days", "6")

catalog                  = dbutils.widgets.get("catalog")
schema                   = dbutils.widgets.get("schema")
model_name               = dbutils.widgets.get("model_name")
min_training_rows        = int(dbutils.widgets.get("min_training_rows"))
freshness_max_age_h      = int(dbutils.widgets.get("freshness_max_age_h"))
min_retrain_interval_days = int(dbutils.widgets.get("min_retrain_interval_days"))

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.jobs import RunResultState
from pyspark.sql import SparkSession
import json, urllib.request, pandas as pd
from datetime import datetime, timedelta, timezone

spark = SparkSession.builder.getOrCreate()
w     = WorkspaceClient()

feature_table     = f"{catalog}.{schema}.customer_churn_features"
training_log      = f"{catalog}.{schema}.retraining_trigger_log"
training_job_name = f"[{catalog.split('_')[0]}] Model Training"

# COMMAND ----------
# MAGIC %md ## 1. Data Freshness Check

freshness_row = spark.sql(f"""
    SELECT
        MAX(feature_timestamp)             AS latest_ts,
        COUNT(DISTINCT customer_id)        AS row_count,
        TIMESTAMPDIFF(HOUR, MAX(feature_timestamp), CURRENT_TIMESTAMP()) AS age_hours
    FROM {feature_table}
""").collect()[0]

latest_ts  = freshness_row["latest_ts"]
row_count  = freshness_row["row_count"] or 0
age_hours  = freshness_row["age_hours"] or 9999

print(f"Feature table freshness check")
print(f"  Latest timestamp : {latest_ts}")
print(f"  Age (hours)      : {age_hours:.1f}h  (threshold {freshness_max_age_h}h)")
print(f"  Row count        : {row_count:,}  (minimum {min_training_rows:,})")

if latest_ts is None:
    raise ValueError(f"Feature table {feature_table} is EMPTY — cannot retrain")

if age_hours > freshness_max_age_h:
    raise ValueError(
        f"Feature table stale: {age_hours:.1f}h old (max {freshness_max_age_h}h). "
        "Run feature_engineering_job first."
    )

if row_count < min_training_rows:
    raise ValueError(
        f"Insufficient training data: {row_count:,} rows (minimum {min_training_rows:,})"
    )

print(f"\n✓ Freshness gate passed — data is fresh and sufficient")

# COMMAND ----------
# MAGIC %md ## 2. Retraining Interval Check
# MAGIC Skip if a triggered or scheduled retrain already ran recently.

try:
    last_retrain = spark.sql(f"""
        SELECT MAX(triggered_at) AS last_run
        FROM {training_log}
        WHERE catalog = '{catalog}'
    """).collect()[0]["last_run"]
except Exception:
    last_retrain = None   # table may not exist yet on first run

if last_retrain is not None:
    days_since = (datetime.now(timezone.utc) - last_retrain.astimezone(timezone.utc).replace(tzinfo=timezone.utc)).days
    print(f"Last retraining : {last_retrain}  ({days_since}d ago)")
    if days_since < min_retrain_interval_days:
        print(
            f"✓ Skipping — last retrain was {days_since}d ago "
            f"(minimum interval {min_retrain_interval_days}d)"
        )
        dbutils.notebook.exit("SKIPPED_RECENT_RETRAIN")
else:
    print("No previous retraining found — proceeding with first scheduled run")

# COMMAND ----------
# MAGIC %md ## 3. Trigger model_training_job

try:
    training_job = next(
        j for j in w.jobs.list()
        if j.settings and training_job_name in (j.settings.name or "")
    )
except StopIteration:
    raise RuntimeError(f"Training job '{training_job_name}' not found — is the bundle deployed?")

run = w.jobs.run_now(
    job_id=training_job.job_id,
    job_parameters={
        "catalog":    catalog,
        "schema":     schema,
        "model_name": model_name,
    },
)

print(f"\n✓ Scheduled retraining triggered")
print(f"  Job  : {training_job.settings.name}")
print(f"  Run  : {run.run_id}")

# COMMAND ----------
# MAGIC %md ## 4. Wait for Completion and Validate Deployment
# MAGIC Polls the run every 60 s (max 90 min) then confirms the new model was registered.

import time

max_wait_secs = 90 * 60
poll_interval = 60
elapsed       = 0
final_state   = None

print(f"\nPolling run {run.run_id} (max {max_wait_secs//60}min)...")
while elapsed < max_wait_secs:
    run_state = w.jobs.get_run(run_id=run.run_id).state
    lc        = run_state.life_cycle_state.value if run_state.life_cycle_state else "UNKNOWN"
    print(f"  [{elapsed:4}s] state={lc}")
    if lc in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        final_state = run_state.result_state
        break
    time.sleep(poll_interval)
    elapsed += poll_interval

if final_state != RunResultState.SUCCESS:
    raise RuntimeError(
        f"Scheduled retraining run {run.run_id} did not succeed — final state: {final_state}"
    )

print(f"\n✓ Retraining pipeline completed successfully (run {run.run_id})")

# COMMAND ----------
# MAGIC %md ## 5. Log + Notify

log_row = [{
    "catalog":          catalog,
    "model_name":       model_name,
    "trigger_reason":   "scheduled_weekly",
    "drift_alert":      False,
    "perf_alert":       False,
    "champion_auc":     None,
    "training_job_id":  str(training_job.job_id),
    "training_run_id":  str(run.run_id),
    "triggered_at":     pd.Timestamp.utcnow(),
}]

(
    spark.createDataFrame(pd.DataFrame(log_row))
    .write.format("delta").mode("append")
    .option("mergeSchema", True)
    .saveAsTable(f"{catalog}.{schema}.retraining_trigger_log")
)

try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
    payload = json.dumps({
        "text": (
            f":white_check_mark: *Scheduled retraining complete [{catalog.split('_')[0].upper()}]*\n"
            f"  Training run {run.run_id} succeeded.\n"
            f"  New challenger registered and validated."
        ),
        "username": "MLOps Scheduler",
    }).encode("utf-8")
    req = urllib.request.Request(
        slack_url, data=payload, headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)
except Exception:
    pass
