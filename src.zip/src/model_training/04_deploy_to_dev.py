# Databricks notebook source
# MAGIC %md
# MAGIC # Deploy to Environment — Canary Traffic Split
# MAGIC
# MAGIC **Position in pipeline:** train_model → register_model → compliance_check → validate_model → **deploy_to_dev**
# MAGIC
# MAGIC Final step of the Databricks Recommended MLOps Workflow "Deploy to dev" stage.
# MAGIC All upstream gates must have passed before this task runs:
# MAGIC   - compliance_status = APPROVED
# MAGIC   - model_validation_status = PASSED
# MAGIC
# MAGIC **Canary deployment strategy (Level 3 MLOps):**
# MAGIC 1. If an existing champion is running, split traffic: 80% champion / 20% challenger
# MAGIC 2. If no champion exists (first deploy), route 100% to challenger
# MAGIC 3. `05_canary_promote.py` monitors canary AUC and either promotes or rolls back
# MAGIC
# MAGIC What this step does:
# MAGIC 1. Confirms all upstream checks passed (hard gate — fails fast if not)
# MAGIC 2. Sets "challenger" alias on the validated model version
# MAGIC 3. Creates or updates serving endpoint with canary traffic split
# MAGIC 4. Persists canary_start_time and initial traffic config to audit table
# MAGIC 5. Prints deployment summary

# COMMAND ----------
dbutils.widgets.text("catalog",                "dev_catalog")
dbutils.widgets.text("schema",                 "mlops_demo")
dbutils.widgets.text("model_name",             "churn_classifier")
dbutils.widgets.text("endpoint_workload_size", "Small")
dbutils.widgets.text("canary_traffic_pct",     "20")   # % of traffic sent to challenger initially

catalog                = dbutils.widgets.get("catalog")
schema                 = dbutils.widgets.get("schema")
model_name             = dbutils.widgets.get("model_name")
endpoint_workload_size = dbutils.widgets.get("endpoint_workload_size")
canary_traffic_pct     = int(dbutils.widgets.get("canary_traffic_pct"))

import mlflow
import datetime
import time
import json
import urllib.request
from mlflow import MlflowClient
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import (
    ServedModelInput,
    ServedModelInputWorkloadSize,
    EndpointCoreConfigInput,
    TrafficConfig,
    Route,
)
from pyspark.sql import functions as F

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
w      = WorkspaceClient()

full_model_name = f"{catalog}.{schema}.{model_name}"
endpoint_name   = f"churn-classifier-{catalog.replace('_catalog','')}"

run_id        = dbutils.jobs.taskValues.get(taskKey="train_model",      key="run_id")
version       = dbutils.jobs.taskValues.get(taskKey="register_model",   key="model_version",    debugValue="2")
compliance_ok = dbutils.jobs.taskValues.get(taskKey="compliance_check", key="compliance_status", debugValue="APPROVED")
validation_ok = dbutils.jobs.taskValues.get(taskKey="validate_model",   key="validation_status", debugValue="PASSED")

print(f"Deploy target:     {full_model_name} v{version}")
print(f"Endpoint:          {endpoint_name}")
print(f"Compliance status: {compliance_ok}")
print(f"Validation status: {validation_ok}")
print(f"Canary traffic:    {canary_traffic_pct}% → challenger")

# COMMAND ----------
# MAGIC %md ## 1. Gate — Confirm All Upstream Checks Passed

if compliance_ok != "APPROVED":
    raise ValueError(
        f"Deploy blocked: compliance_status={compliance_ok}. "
        "Fix compliance failures and re-run the training pipeline."
    )

if validation_ok != "PASSED":
    raise ValueError(
        f"Deploy blocked: validation_status={validation_ok}. "
        "Model did not meet AUC/precision/recall thresholds."
    )

print("✓ All upstream gates passed — proceeding with canary deployment")

# COMMAND ----------
# MAGIC %md ## 2. Set Challenger Alias in Unity Catalog

mv = client.get_model_version(full_model_name, version)
current_aliases = list(mv.aliases) if mv.aliases else []
print(f"\nCurrent aliases on v{version}: {current_aliases}")

client.set_registered_model_alias(
    name=full_model_name,
    alias="challenger",
    version=version,
)

deploy_ts = datetime.datetime.utcnow().isoformat()
client.set_model_version_tag(full_model_name, version, "deployment_stage",    "CANARY")
client.set_model_version_tag(full_model_name, version, "deployed_at",         deploy_ts)
client.set_model_version_tag(full_model_name, version, "deployed_env",        catalog.replace("_catalog", ""))
client.set_model_version_tag(full_model_name, version, "canary_traffic_pct",  str(canary_traffic_pct))

print(f"✓ 'challenger' alias set on {full_model_name} v{version}")

# COMMAND ----------
# MAGIC %md ## 3. Resolve Champion Version (for traffic split)
# MAGIC If no champion exists yet (first deploy) → 100% to challenger.
# MAGIC If champion exists → split traffic: {100-canary_pct}% champion / {canary_pct}% challenger.

champion_version_str = None
try:
    champion_mv = client.get_model_version_by_alias(full_model_name, "champion")
    champion_version_str = champion_mv.version
    print(f"✓ Existing champion: v{champion_version_str} — deploying canary split")
except Exception:
    print("ℹ No champion alias found — first deploy: 100% traffic to challenger")

# COMMAND ----------
# MAGIC %md ## 4. Create or Update Serving Endpoint with Canary Traffic Split

workload_size_enum = ServedModelInputWorkloadSize[endpoint_workload_size.upper()]

try:
    existing_endpoints = {e.name for e in w.serving_endpoints.list()}

    if champion_version_str and endpoint_name in existing_endpoints:
        # ── Canary split: champion holds majority, challenger gets canary slice ──
        champion_pct   = 100 - canary_traffic_pct
        challenger_pct = canary_traffic_pct

        champion_served = ServedModelInput(
            name=f"champion-v{champion_version_str}",
            model_name=full_model_name,
            model_version=str(champion_version_str),
            workload_size=workload_size_enum,
            scale_to_zero_enabled=True,
        )
        challenger_served = ServedModelInput(
            name=f"challenger-v{version}",
            model_name=full_model_name,
            model_version=str(version),
            workload_size=workload_size_enum,
            scale_to_zero_enabled=True,
        )
        traffic = TrafficConfig(routes=[
            Route(served_model_name=f"champion-v{champion_version_str}", traffic_percentage=champion_pct),
            Route(served_model_name=f"challenger-v{version}",            traffic_percentage=challenger_pct),
        ])
        endpoint_config = EndpointCoreConfigInput(
            served_models=[champion_served, challenger_served],
            traffic_config=traffic,
        )
        w.serving_endpoints.update_config(
            name=endpoint_name,
            served_models=[champion_served, challenger_served],
            traffic_config=traffic,
        )
        action = f"CANARY_SPLIT ({champion_pct}% champion / {challenger_pct}% challenger)"
        print(f"✓ Canary deployment: {action}")

    else:
        # ── First deploy: no champion yet → 100% to challenger ──────────────
        challenger_served = ServedModelInput(
            name=f"challenger-v{version}",
            model_name=full_model_name,
            model_version=str(version),
            workload_size=workload_size_enum,
            scale_to_zero_enabled=True,
        )
        traffic = TrafficConfig(routes=[
            Route(served_model_name=f"challenger-v{version}", traffic_percentage=100),
        ])
        endpoint_config = EndpointCoreConfigInput(
            served_models=[challenger_served],
            traffic_config=traffic,
        )
        if endpoint_name in existing_endpoints:
            w.serving_endpoints.update_config(
                name=endpoint_name,
                served_models=[challenger_served],
                traffic_config=traffic,
            )
        else:
            w.serving_endpoints.create(name=endpoint_name, config=endpoint_config)
        action = "FULL_DEPLOY (no prior champion)"
        print(f"✓ Full deploy (first time): {action}")

    endpoint_url = f"{w.config.host}/serving-endpoints/{endpoint_name}/invocations"
    print(f"  Endpoint URL: {endpoint_url}")

except Exception as e:
    print(f"⚠ Serving endpoint step skipped (non-fatal in dev): {e}")
    action = "SKIPPED"

# COMMAND ----------
# MAGIC %md ## 5. Warm-up Requests — Eliminate Cold-Start Latency
# MAGIC
# MAGIC After every deployment, send 10 synthetic requests to warm up the serving endpoint.
# MAGIC Without this, the first real user request triggers model loading (~2-5 s cold start).
# MAGIC Warm-up requests use a synthetic customer_id that is safe to route to any model version.

def _send_warmup_requests(w, endpoint_name, endpoint_url, n: int = 10) -> None:
    # Wait for endpoint to reach READY state (up to 5 minutes)
    for _ in range(30):
        try:
            state = w.serving_endpoints.get(name=endpoint_name).state
            if state and getattr(state, "ready", None) == "READY":
                break
        except Exception:
            pass
        time.sleep(10)

    token   = w.config.token
    payload = json.dumps({
        "dataframe_records": [{"customer_id": f"warmup_{i:04d}"} for i in range(n)]
    }).encode()
    req = urllib.request.Request(
        endpoint_url,
        data=payload,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        urllib.request.urlopen(req, timeout=15)
        print(f"✓ {n} warm-up requests sent — cold-start latency eliminated")
    except Exception as e:
        print(f"  ⚠ Warm-up request failed (non-fatal — endpoint may still be initialising): {e}")

if action != "SKIPPED":
    _send_warmup_requests(w, endpoint_name, endpoint_url)

# COMMAND ----------
# MAGIC %md ## 6. Log Deployment Event + Canary Metadata to Audit Table

try:
    deployment_record = spark.createDataFrame([{
        "trigger_timestamp":   datetime.datetime.utcnow(),
        "trigger_reason":      f"canary_deploy_v{version}",
        "triggered_by":        "deploy_to_dev_task",
        "job_run_id":          None,
        "status":              f"DEPLOYED:{action}",
        "canary_traffic_pct":  canary_traffic_pct,
        "champion_version":    champion_version_str or "none",
        "challenger_version":  str(version),
        "canary_start_ts":     deploy_ts,
    }])
    deployment_record.write.mode("append").option("mergeSchema", True).saveAsTable(
        f"{catalog}.{schema}.retraining_trigger_log"
    )
    print(f"✓ Canary deployment event logged to retraining_trigger_log")
except Exception as e:
    print(f"⚠ Audit log write skipped: {e}")

# COMMAND ----------
# MAGIC %md ## 7. Deployment Summary

auc = dbutils.jobs.taskValues.get(taskKey="train_model", key="auc", debugValue="0.0")

print("\n" + "="*70)
print(f"  CANARY DEPLOYMENT COMPLETE")
print("="*70)
print(f"  Model        : {full_model_name}")
print(f"  Version      : v{version}  (challenger)")
print(f"  Champion     : v{champion_version_str or 'N/A'}")
print(f"  AUC          : {auc}")
print(f"  Compliance   : {compliance_ok}")
print(f"  Validation   : {validation_ok}")
print(f"  Endpoint     : {endpoint_name}")
print(f"  Traffic      : {action}")
print(f"  Environment  : {catalog.replace('_catalog','')}")
print(f"  Next step    : canary_promote_job monitors and promotes/rolls back automatically")
print("="*70)

dbutils.jobs.taskValues.set("deployed_version",    str(version))
dbutils.jobs.taskValues.set("endpoint_name",        endpoint_name)
dbutils.jobs.taskValues.set("champion_version",     str(champion_version_str or "none"))
dbutils.jobs.taskValues.set("canary_traffic_pct",   str(canary_traffic_pct))
