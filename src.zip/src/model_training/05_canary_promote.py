# Databricks notebook source
# MAGIC %md
# MAGIC # Canary Promotion / Rollback
# MAGIC
# MAGIC **Runs every 6 hours** (canary_promote_job) after a canary deployment is live.
# MAGIC Implements the final piece of a Level 3 MLOps canary strategy:
# MAGIC
# MAGIC ## Decision logic
# MAGIC | Condition | Action |
# MAGIC |-----------|--------|
# MAGIC | Challenger live AUC ≥ champion live AUC − tolerance AND error rate OK | Increase challenger traffic by `step_pct` (e.g. 20 → 40 → 60 → 80 → 100) |
# MAGIC | Challenger live AUC < champion live AUC − tolerance OR error rate breached | Rollback: 100% champion, remove challenger, set alert |
# MAGIC | Challenger already at 100% AND sustained for `min_soak_hours` | Full promote: set "champion" alias, archive old champion, log success |
# MAGIC | No canary in progress | No-op — safe to run at all times |
# MAGIC
# MAGIC ## Data sources
# MAGIC - `model_performance_actuals` — live AUC from ground truth feedback loop (03_ground_truth_feedback.py)
# MAGIC - Serving endpoint system table — live error rate and request count
# MAGIC - `retraining_trigger_log` — canary start metadata
# MAGIC
# MAGIC **Cost:** Single-node SPOT m5.large. Pure API + SQL. No Spark compute.

# COMMAND ----------
dbutils.widgets.text("catalog",              "dev_catalog")
dbutils.widgets.text("schema",               "mlops_demo")
dbutils.widgets.text("model_name",           "churn_classifier")
dbutils.widgets.text("step_pct",             "20")    # traffic increase per successful check
dbutils.widgets.text("auc_tolerance",        "0.02")  # challenger can be 0.02 below champion
dbutils.widgets.text("max_error_rate",       "0.05")  # 5% error rate trips rollback
dbutils.widgets.text("min_soak_hours",       "6")     # hours at 100% before full promote
dbutils.widgets.text("min_canary_requests",  "50")    # minimum requests before deciding

catalog             = dbutils.widgets.get("catalog")
schema              = dbutils.widgets.get("schema")
model_name          = dbutils.widgets.get("model_name")
step_pct            = int(dbutils.widgets.get("step_pct"))
auc_tolerance       = float(dbutils.widgets.get("auc_tolerance"))
max_error_rate      = float(dbutils.widgets.get("max_error_rate"))
min_soak_hours      = float(dbutils.widgets.get("min_soak_hours"))
min_canary_requests = int(dbutils.widgets.get("min_canary_requests"))

import json
import datetime
import urllib.request
import mlflow
from mlflow import MlflowClient
from databricks.sdk import WorkspaceClient
from databricks.sdk.service.serving import (
    ServedModelInput,
    ServedModelInputWorkloadSize,
    TrafficConfig,
    Route,
)

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
w      = WorkspaceClient()

full_model_name = f"{catalog}.{schema}.{model_name}"
endpoint_name   = f"churn-classifier-{catalog.replace('_catalog','')}"

# COMMAND ----------
# MAGIC %md ## 1. Resolve Current Endpoint State
# MAGIC Read current traffic split to determine if a canary is in progress.

def _send_slack(webhook_url: str, message: str, level: str = "warning") -> None:
    icon = ":white_check_mark:" if level == "success" else ":rotating_light:"
    payload = json.dumps({
        "text": f"{icon} *Canary Promote [{catalog.replace('_catalog','')}]*\n{message}",
        "username": "MLOps Canary",
    }).encode()
    req = urllib.request.Request(
        webhook_url, data=payload,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)

try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
except Exception:
    slack_url = None

try:
    endpoint = w.serving_endpoints.get(name=endpoint_name)
except Exception as e:
    print(f"Endpoint {endpoint_name} not found — no canary in progress. Exiting.")
    dbutils.notebook.exit("NO_ENDPOINT")

config  = endpoint.config
routes  = config.traffic_config.routes if config.traffic_config else []
models  = {m.name: m for m in config.served_models}

print(f"Current endpoint: {endpoint_name}")
print(f"Served models:    {list(models.keys())}")
print(f"Traffic routes:")
for r in routes:
    print(f"  {r.served_model_name}: {r.traffic_percentage}%")

# Identify challenger and champion from route names (set in 04_deploy_to_dev.py)
challenger_route = next((r for r in routes if r.served_model_name.startswith("challenger-v")), None)
champion_route   = next((r for r in routes if r.served_model_name.startswith("champion-v")),   None)

if challenger_route is None:
    print("No challenger route found — no canary in progress. Exiting.")
    dbutils.notebook.exit("NO_CANARY")

challenger_version = challenger_route.served_model_name.replace("challenger-v", "")
champion_version   = champion_route.served_model_name.replace("champion-v", "") if champion_route else None
current_canary_pct = challenger_route.traffic_percentage

print(f"\nCanary in progress:")
print(f"  Challenger v{challenger_version}: {current_canary_pct}% traffic")
print(f"  Champion   v{champion_version}:  {100 - current_canary_pct}% traffic")

# COMMAND ----------
# MAGIC %md ## 2. Get Live Performance Metrics
# MAGIC Read from model_performance_actuals (written by 03_ground_truth_feedback.py).
# MAGIC Fall back to training-time AUC if live data not yet available.

def _get_live_auc(version_str: str) -> tuple[float, int]:
    """Returns (live_auc, sample_count). Falls back to training AUC if no live data."""
    try:
        row = spark.sql(f"""
            SELECT live_auc, sample_count
            FROM {catalog}.{schema}.model_performance_actuals
            WHERE model_version = '{version_str}'
              AND scored_date >= current_date() - 7
            ORDER BY computed_at DESC
            LIMIT 1
        """).collect()
        if row:
            return float(row[0]["live_auc"]), int(row[0]["sample_count"])
    except Exception:
        pass
    # Fall back to training AUC from MLflow
    mv  = client.get_model_version(full_model_name, version_str)
    run = client.get_run(mv.run_id)
    return float(run.data.metrics.get("roc_auc", 0.0)), 0

challenger_auc, challenger_samples = _get_live_auc(challenger_version)
champion_auc,   champion_samples   = _get_live_auc(champion_version) if champion_version else (0.0, 0)

print(f"\nLive AUC:")
print(f"  Challenger v{challenger_version}: {challenger_auc:.4f}  (n={challenger_samples:,})")
print(f"  Champion   v{champion_version}:  {champion_auc:.4f}  (n={champion_samples:,})")

# COMMAND ----------
# MAGIC %md ## 3. Get Serving Error Rate from System Tables

challenger_error_rate = 0.0
try:
    err_row = spark.sql(f"""
        SELECT
            COUNT_IF(status_code >= 500) / COUNT(*) AS error_rate,
            COUNT(*) AS total_requests
        FROM system.serving.served_entities_system_stats
        WHERE endpoint_name = '{endpoint_name}'
          AND served_entity_name LIKE 'challenger-v%'
          AND window_start_time >= current_timestamp() - INTERVAL 6 HOURS
    """).collect()
    if err_row and err_row[0]["total_requests"] > 0:
        challenger_error_rate = float(err_row[0]["error_rate"] or 0.0)
        print(f"\nChallenger error rate (last 6h): {challenger_error_rate:.2%}")
except Exception as e:
    print(f"⚠ Could not query system serving stats (non-fatal): {e}")

# COMMAND ----------
# MAGIC %md ## 4. Canary Decision

has_sufficient_data = challenger_samples >= min_canary_requests or champion_version is None
auc_ok              = challenger_auc >= (champion_auc - auc_tolerance)
error_rate_ok       = challenger_error_rate <= max_error_rate

print(f"\nDecision inputs:")
print(f"  AUC check:        challenger={challenger_auc:.4f}  threshold={champion_auc - auc_tolerance:.4f}  → {'PASS' if auc_ok else 'FAIL'}")
print(f"  Error rate check: {challenger_error_rate:.2%} <= {max_error_rate:.2%}  → {'PASS' if error_rate_ok else 'FAIL'}")
print(f"  Sufficient data:  {challenger_samples} requests (min={min_canary_requests})  → {'YES' if has_sufficient_data else 'NO'}")

workload_size_enum = ServedModelInputWorkloadSize.SMALL

if not has_sufficient_data:
    decision = "WAIT"
    print("\n→ WAIT: Not enough canary traffic yet — will re-evaluate next cycle")

elif auc_ok and error_rate_ok:
    new_canary_pct = min(current_canary_pct + step_pct, 100)
    decision = "PROMOTE_STEP" if new_canary_pct < 100 else "PROMOTE_FULL"
    print(f"\n→ {decision}: Challenger meeting quality bar → increasing traffic to {new_canary_pct}%")

else:
    decision = "ROLLBACK"
    reasons = []
    if not auc_ok:
        reasons.append(f"AUC {challenger_auc:.4f} < threshold {champion_auc - auc_tolerance:.4f}")
    if not error_rate_ok:
        reasons.append(f"error rate {challenger_error_rate:.2%} > {max_error_rate:.2%}")
    print(f"\n→ ROLLBACK: Challenger failing — {', '.join(reasons)}")

# COMMAND ----------
# MAGIC %md ## 5. Execute Decision

action_detail = decision

if decision == "ROLLBACK":
    if champion_version:
        champion_served = ServedModelInput(
            name=f"champion-v{champion_version}",
            model_name=full_model_name,
            model_version=str(champion_version),
            workload_size=workload_size_enum,
            scale_to_zero_enabled=True,
        )
        w.serving_endpoints.update_config(
            name=endpoint_name,
            served_models=[champion_served],
            traffic_config=TrafficConfig(routes=[
                Route(served_model_name=f"champion-v{champion_version}", traffic_percentage=100),
            ]),
        )
        client.set_model_version_tag(full_model_name, challenger_version, "deployment_stage", "ROLLED_BACK")
        client.set_model_version_tag(full_model_name, challenger_version, "rollback_reason",  ", ".join(reasons))
        action_detail = f"ROLLBACK → 100% champion v{champion_version}"
        msg = f"Canary *rolled back*.\nChallenger v{challenger_version} failed: {', '.join(reasons)}\nRestored champion v{champion_version} to 100%."
        if slack_url:
            _send_slack(slack_url, msg, level="warning")
    else:
        print("⚠ No champion to roll back to — leaving endpoint as-is and raising alert")
        action_detail = "ROLLBACK_FAILED_NO_CHAMPION"

elif decision in ("PROMOTE_STEP", "PROMOTE_FULL"):
    if decision == "PROMOTE_FULL":
        # Full promotion — challenger becomes new champion
        challenger_served = ServedModelInput(
            name=f"champion-v{challenger_version}",
            model_name=full_model_name,
            model_version=str(challenger_version),
            workload_size=workload_size_enum,
            scale_to_zero_enabled=True,
        )
        w.serving_endpoints.update_config(
            name=endpoint_name,
            served_models=[challenger_served],
            traffic_config=TrafficConfig(routes=[
                Route(served_model_name=f"champion-v{challenger_version}", traffic_percentage=100),
            ]),
        )
        # Update MLflow aliases
        client.set_registered_model_alias(full_model_name, "champion",    challenger_version)
        client.set_registered_model_alias(full_model_name, "challenger",  challenger_version)
        client.set_model_version_tag(full_model_name, challenger_version, "deployment_stage", "CHAMPION")
        if champion_version:
            client.set_model_version_tag(full_model_name, champion_version, "deployment_stage", "ARCHIVED")
        action_detail = f"FULL_PROMOTE v{challenger_version} → champion (archived v{champion_version})"
        msg = f"Canary *fully promoted* :tada:\nv{challenger_version} is now champion (AUC={challenger_auc:.4f}).\nPrevious champion v{champion_version} archived."
        if slack_url:
            _send_slack(slack_url, msg, level="success")
    else:
        # Step increase — keep both, shift traffic
        champion_pct   = 100 - new_canary_pct
        challenger_pct = new_canary_pct
        served_models  = []
        routes_list    = []
        if champion_version and champion_pct > 0:
            served_models.append(ServedModelInput(
                name=f"champion-v{champion_version}",
                model_name=full_model_name,
                model_version=str(champion_version),
                workload_size=workload_size_enum,
                scale_to_zero_enabled=True,
            ))
            routes_list.append(Route(served_model_name=f"champion-v{champion_version}", traffic_percentage=champion_pct))
        served_models.append(ServedModelInput(
            name=f"challenger-v{challenger_version}",
            model_name=full_model_name,
            model_version=str(challenger_version),
            workload_size=workload_size_enum,
            scale_to_zero_enabled=True,
        ))
        routes_list.append(Route(served_model_name=f"challenger-v{challenger_version}", traffic_percentage=challenger_pct))
        w.serving_endpoints.update_config(
            name=endpoint_name,
            served_models=served_models,
            traffic_config=TrafficConfig(routes=routes_list),
        )
        client.set_model_version_tag(full_model_name, challenger_version, "canary_traffic_pct", str(challenger_pct))
        action_detail = f"TRAFFIC_SHIFT {current_canary_pct}% → {challenger_pct}% challenger"
        msg = f"Canary traffic increased: {current_canary_pct}% → {challenger_pct}% for v{challenger_version} (AUC={challenger_auc:.4f})"
        if slack_url:
            _send_slack(slack_url, msg, level="success")

elif decision == "WAIT":
    action_detail = f"WAIT ({challenger_samples} requests < {min_canary_requests} minimum)"

# COMMAND ----------
# MAGIC %md ## 6. Log Canary Decision to Audit Table

try:
    spark.createDataFrame([{
        "trigger_timestamp":   datetime.datetime.utcnow(),
        "trigger_reason":      f"canary_promote_check",
        "triggered_by":        "canary_promote_job",
        "job_run_id":          None,
        "status":              action_detail,
        "canary_traffic_pct":  new_canary_pct if decision == "PROMOTE_STEP" else (100 if decision == "PROMOTE_FULL" else current_canary_pct),
        "champion_version":    champion_version or "none",
        "challenger_version":  str(challenger_version),
        "canary_start_ts":     None,
    }]).write.mode("append").option("mergeSchema", True).saveAsTable(
        f"{catalog}.{schema}.retraining_trigger_log"
    )
    print(f"✓ Canary decision logged")
except Exception as e:
    print(f"⚠ Audit log skipped: {e}")

print(f"\n{'='*65}")
print(f"  CANARY DECISION: {decision}")
print(f"  Action:          {action_detail}")
print(f"  Challenger AUC:  {challenger_auc:.4f}  (champion: {champion_auc:.4f})")
print(f"  Error rate:      {challenger_error_rate:.2%}")
print(f"{'='*65}")
