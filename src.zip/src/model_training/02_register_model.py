# Databricks notebook source
# MAGIC %md
# MAGIC # Model Registration — Unity Catalog Model Registry
# MAGIC Registers the trained model with versioning, aliases, and approval gates.
# MAGIC
# MAGIC **UC lifecycle governance tags applied:**
# MAGIC - `git_commit` / `git_branch` — pins version to exact code revision
# MAGIC - `feature_table_version` — Delta version used for training (reproducibility)
# MAGIC - `data_cutoff_date` — latest training data timestamp (lineage)
# MAGIC - `compliance_status` — PENDING_REVIEW → approved by validation gate
# MAGIC - `deployment_stage` — challenger → champion (set by promote_model.py)

# COMMAND ----------
dbutils.widgets.text("catalog",    "dev_catalog")
dbutils.widgets.text("schema",     "mlops_demo")
dbutils.widgets.text("model_name", "churn_classifier")
dbutils.widgets.text("min_auc",    "0.75")

catalog    = dbutils.widgets.get("catalog")
schema     = dbutils.widgets.get("schema")
model_name = dbutils.widgets.get("model_name")
min_auc    = float(dbutils.widgets.get("min_auc"))

import mlflow
from mlflow import MlflowClient
from pyspark.sql import SparkSession, functions as F

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
spark  = SparkSession.builder.getOrCreate()

full_model_name    = f"{catalog}.{schema}.{model_name}"
feature_table_name = f"{catalog}.{schema}.customer_churn_features"

# COMMAND ----------
# MAGIC %md ## 1. Retrieve Training Run and Validate AUC Gate

run_id = dbutils.jobs.taskValues.get(taskKey="train_model", key="run_id")
auc    = float(dbutils.jobs.taskValues.get(taskKey="train_model", key="auc"))

print(f"Run ID : {run_id}")
print(f"AUC    : {auc}")

if auc < min_auc:
    raise ValueError(
        f"Model AUC {auc:.4f} is below minimum threshold {min_auc}. "
        "Registration blocked. Retrain with improved features or hyperparameters."
    )

print(f"✓ AUC gate passed ({auc:.4f} ≥ {min_auc})")

# COMMAND ----------
# MAGIC %md ## 2. Collect Lineage Metadata
# MAGIC Read git tags and feature table Delta version from the training run —
# MAGIC stored in UC model version tags for full reproducibility.

training_run = client.get_run(run_id)
run_tags     = training_run.data.tags

git_commit   = run_tags.get("mlflow.source.git.commit",  "unknown")
git_branch   = run_tags.get("mlflow.source.git.branch",  "unknown")
git_url      = run_tags.get("mlflow.source.git.repoURL", "unknown")
nb_path      = run_tags.get("mlflow.source.name",        "unknown")

# Delta version of feature table used during training — enables time-travel replay
try:
    feature_history = spark.sql(
        f"DESCRIBE HISTORY {feature_table_name} LIMIT 1"
    ).collect()[0]
    feature_table_version = str(feature_history["version"])
    data_cutoff_date      = str(feature_history["timestamp"])
except Exception:
    feature_table_version = "unknown"
    data_cutoff_date      = "unknown"

print(f"Git commit            : {git_commit}")
print(f"Feature table version : {feature_table_version}  ({data_cutoff_date})")

# COMMAND ----------
# MAGIC %md ## 3. Register to Unity Catalog with Full Governance Tags

model_uri = f"runs:/{run_id}/model"

model_version = mlflow.register_model(
    model_uri=model_uri,
    name=full_model_name,
    tags={
        # Identity
        "run_id":                  run_id,
        "team":                    "mlops",
        "environment":             catalog.split("_")[0],
        # Quality
        "auc":                     str(round(auc, 4)),
        # Git version control — every version pinned to a commit
        "git_commit":              git_commit,
        "git_branch":              git_branch,
        "git_url":                 git_url,
        "source_notebook":         nb_path,
        # Data lineage — links model to exact training data snapshot
        "feature_table":           feature_table_name,
        "feature_table_version":   feature_table_version,
        "data_cutoff_date":        data_cutoff_date,
        # UC lifecycle governance
        "compliance_status":       "PENDING_REVIEW",   # updated to APPROVED after validation
        "deployment_stage":        "challenger",
    },
)

version = model_version.version
print(f"✓ Registered: {full_model_name} version {version}")

# COMMAND ----------
# MAGIC %md ## 4. Set Alias and UC Model Description

client.set_registered_model_alias(
    name=full_model_name,
    alias="challenger",
    version=version,
)

client.update_model_version(
    name=full_model_name,
    version=version,
    description=(
        f"Gradient Boosting churn classifier. "
        f"AUC={auc:.4f}. "
        f"Trained from Git commit {git_commit[:8]} on branch '{git_branch}'. "
        f"Feature data: {feature_table_name} v{feature_table_version} ({data_cutoff_date}). "
        f"MLflow run: {run_id}. "
        f"Compliance: PENDING_REVIEW — awaiting validation gate."
    ),
)

# Update the registered model's top-level description (shown in UC catalog UI)
try:
    client.update_registered_model(
        name=full_model_name,
        description=(
            f"Customer churn binary classifier managed by MLOps team. "
            f"Uses Unity Catalog for versioning, governance, and deployment lifecycle. "
            f"Aliases: challenger (new), champion (production-approved). "
            f"Lineage tracked via MLflow + feature table Delta versions."
        ),
    )
except Exception:
    pass   # already set — non-fatal

# COMMAND ----------
# MAGIC %md ## 5. Log Version + Governance Summary

print(f"\n{'='*60}")
print(f"  Model     : {full_model_name}")
print(f"  Version   : {version}")
print(f"  AUC       : {auc:.4f}")
print(f"  Git       : {git_branch} @ {git_commit[:12]}")
print(f"  Data      : {feature_table_name} v{feature_table_version}")
print(f"  Compliance: PENDING_REVIEW")
print(f"  Alias     : challenger")
print()
print("Model aliases:")
for alias_obj in client.get_registered_model(full_model_name).aliases:
    print(f"  {alias_obj.alias:15} → version {alias_obj.version}")

dbutils.jobs.taskValues.set("model_version", str(version))
