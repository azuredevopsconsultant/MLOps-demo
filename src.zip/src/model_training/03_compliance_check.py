# Databricks notebook source
# MAGIC %md
# MAGIC # Compliance Checks — Bias, Fairness & Regulatory Gate
# MAGIC
# MAGIC **Position in pipeline:** train_model → register_model → **compliance_check** → validate_model → deploy_to_dev
# MAGIC
# MAGIC This notebook implements the "Compliance checks" step from the Databricks Recommended
# MAGIC MLOps Workflow. It runs AFTER model registration and BEFORE pre-deployment validation.
# MAGIC
# MAGIC Gates checked:
# MAGIC 1. **Regulatory tags** — all required UC governance tags are populated
# MAGIC 2. **Prohibited features** — no direct PII columns in the feature set
# MAGIC 3. **Explainability** — SHAP artifacts logged in the MLflow run
# MAGIC 4. **Model card** — completeness check on the logged model card artifact
# MAGIC 5. **Performance parity** — AUC disparity across subgroups ≤ max_parity_gap
# MAGIC 6. **Prediction rate parity** — churn rate gap between demographic groups ≤ max_parity_gap
# MAGIC
# MAGIC Updates `compliance_status` tag: PENDING_REVIEW → APPROVED (pass) or COMPLIANCE_FAILED (fail).
# MAGIC Raises exception to block the downstream validate_model and deploy_to_dev tasks on failure.

# COMMAND ----------
dbutils.widgets.text("catalog",        "dev_catalog")
dbutils.widgets.text("schema",         "mlops_demo")
dbutils.widgets.text("model_name",     "churn_classifier")
dbutils.widgets.text("max_parity_gap", "0.10")   # max AUC / rate gap across subgroups

catalog        = dbutils.widgets.get("catalog")
schema         = dbutils.widgets.get("schema")
model_name     = dbutils.widgets.get("model_name")
max_parity_gap = float(dbutils.widgets.get("max_parity_gap"))

import mlflow
import json
from mlflow import MlflowClient
from databricks.feature_engineering import FeatureEngineeringClient
from sklearn.metrics import roc_auc_score
import pandas as pd

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
fe     = FeatureEngineeringClient()

full_model_name = f"{catalog}.{schema}.{model_name}"

run_id  = dbutils.jobs.taskValues.get(taskKey="train_model",   key="run_id")
version = dbutils.jobs.taskValues.get(taskKey="register_model", key="model_version", debugValue="1")

print(f"Compliance check: {full_model_name} v{version}")
print(f"MLflow run:       {run_id}")

failures   = []
warnings   = []
check_log  = {}

# COMMAND ----------
# MAGIC %md ## Check 1 — Required Governance Tags

REQUIRED_TAGS = [
    "git_commit", "git_branch", "git_url",
    "feature_table", "feature_table_version", "data_cutoff_date",
    "auc", "team", "compliance_status", "deployment_stage",
]

mv_tags = {t.key: t.value for t in client.get_model_version(full_model_name, version).tags}
print("\n[1] Governance tag check:")

missing_tags = [t for t in REQUIRED_TAGS if not mv_tags.get(t)]
if missing_tags:
    msg = f"Missing required UC tags: {missing_tags}"
    failures.append(msg)
    print(f"  FAIL — {msg}")
else:
    print(f"  PASS — all {len(REQUIRED_TAGS)} required tags present")

check_log["governance_tags"] = {"status": "FAIL" if missing_tags else "PASS", "missing": missing_tags}

# COMMAND ----------
# MAGIC %md ## Check 2 — Prohibited Features (no direct PII in model input)

PROHIBITED_FEATURES = [
    "email", "phone", "phone_number", "ssn", "national_id",
    "full_name", "first_name", "last_name", "dob", "date_of_birth",
    "ip_address", "device_id",
]

run_data    = client.get_run(run_id)
run_params  = run_data.data.params
feature_str = run_params.get("feature_names", "")

print("\n[2] Prohibited feature check:")

found_pii = [p for p in PROHIBITED_FEATURES if p in feature_str.lower()]
if found_pii:
    msg = f"Prohibited PII features detected in model input: {found_pii}"
    failures.append(msg)
    print(f"  FAIL — {msg}")
else:
    print(f"  PASS — no PII features in model input")

check_log["prohibited_features"] = {"status": "FAIL" if found_pii else "PASS", "found": found_pii}

# COMMAND ----------
# MAGIC %md ## Check 3 — Explainability Artifacts (SHAP must be logged)

print("\n[3] Explainability artifact check:")

artifacts = [a.path for a in client.list_artifacts(run_id)]
shap_present = any("shap" in a.lower() for a in artifacts)
model_card_present = any("model_card" in a.lower() for a in artifacts)

if not shap_present:
    msg = "SHAP artifacts not found in MLflow run — explainability required for compliance"
    failures.append(msg)
    print(f"  FAIL — {msg}")
else:
    print(f"  PASS — SHAP artifacts present")

if not model_card_present:
    msg = "model_card.txt not found in MLflow run — model card required for audit trail"
    warnings.append(msg)
    print(f"  WARN — {msg}")
else:
    print(f"  PASS — model card present")

check_log["explainability"] = {
    "status": "FAIL" if not shap_present else "PASS",
    "shap_present": shap_present,
    "model_card_present": model_card_present,
}

# COMMAND ----------
# MAGIC %md ## Check 4 — Model Card Completeness

print("\n[4] Model card completeness check:")

REQUIRED_CARD_FIELDS = [
    "model_type", "training_data", "features", "intended_use",
    "limitations", "compliance_status",
]

try:
    card_path = [a for a in artifacts if "model_card" in a.lower()][0]
    card_content = client.download_artifacts(run_id, card_path)
    with open(card_content) as f:
        card_text = f.read().lower()

    missing_fields = [field for field in REQUIRED_CARD_FIELDS if field not in card_text]
    if missing_fields:
        warnings.append(f"Model card missing fields: {missing_fields}")
        print(f"  WARN — model card missing fields: {missing_fields}")
    else:
        print(f"  PASS — model card contains all {len(REQUIRED_CARD_FIELDS)} required fields")
    check_log["model_card"] = {"status": "WARN" if missing_fields else "PASS", "missing_fields": missing_fields}
except Exception as e:
    warnings.append(f"Could not parse model card: {e}")
    print(f"  WARN — could not read model card: {e}")
    check_log["model_card"] = {"status": "WARN", "error": str(e)}

# COMMAND ----------
# MAGIC %md ## Check 5 — Performance Parity Across Subgroups
# MAGIC Validates that the model does not discriminate by region or product_tier.
# MAGIC Uses a 20% sample of the gold table to keep compute cost low.

print(f"\n[5] Performance parity check (max_parity_gap={max_parity_gap}):")

SUBGROUP_COLS = ["region", "product_tier"]

try:
    gold_df = (
        spark.table(f"{catalog}.{schema}.gold_customers_ml")
        .sample(fraction=0.2, seed=42)
        .select("customer_id", "label", *SUBGROUP_COLS)
    )

    model_uri   = f"runs:/{run_id}/model"
    scored      = fe.score_batch(model_uri=model_uri, df=gold_df.select("customer_id", "label"))
    scored_pd   = scored.join(gold_df.drop("label"), "customer_id", "left").toPandas()
    scored_pd["label"]      = scored_pd["label"].astype(int)
    scored_pd["prediction"] = scored_pd["prediction"].astype(float)

    parity_issues = []
    overall_auc   = roc_auc_score(scored_pd["label"], scored_pd["prediction"])
    print(f"  Overall AUC: {overall_auc:.4f}")

    for col in SUBGROUP_COLS:
        if col not in scored_pd.columns:
            continue
        group_aucs = {}
        for grp, grp_df in scored_pd.groupby(col):
            if grp_df["label"].nunique() < 2:
                continue
            group_aucs[grp] = roc_auc_score(grp_df["label"], grp_df["prediction"])

        if len(group_aucs) < 2:
            continue

        max_auc = max(group_aucs.values())
        min_auc = min(group_aucs.values())
        gap     = max_auc - min_auc

        print(f"  {col}: AUC range [{min_auc:.4f}, {max_auc:.4f}] — gap={gap:.4f}")

        if gap > max_parity_gap:
            msg = f"Performance gap on '{col}' ({gap:.4f}) exceeds max_parity_gap ({max_parity_gap})"
            failures.append(msg)
            parity_issues.append(msg)
            print(f"    FAIL — {msg}")
        else:
            print(f"    PASS")

    check_log["performance_parity"] = {
        "status": "FAIL" if parity_issues else "PASS",
        "issues": parity_issues,
        "overall_auc": round(overall_auc, 4),
    }

except Exception as e:
    warnings.append(f"Parity check skipped (non-fatal): {e}")
    print(f"  SKIP — {e}")
    check_log["performance_parity"] = {"status": "SKIP", "error": str(e)}

# COMMAND ----------
# MAGIC %md ## Check 6 — Prediction Rate Parity (Demographic Parity)
# MAGIC Ensures predicted churn rates are not disproportionate across regions.

print(f"\n[6] Prediction rate parity check:")

try:
    rate_by_region = (
        scored_pd.groupby("region")["prediction"]
        .apply(lambda x: (x >= 0.5).mean())
        .to_dict()
    )

    max_rate = max(rate_by_region.values())
    min_rate = min(rate_by_region.values())
    rate_gap = max_rate - min_rate

    print(f"  Churn rate by region: { {k: round(v,3) for k,v in rate_by_region.items()} }")
    print(f"  Rate gap: {rate_gap:.4f}")

    if rate_gap > max_parity_gap * 2:   # looser threshold for rate parity
        msg = f"Prediction rate gap by region ({rate_gap:.4f}) exceeds threshold ({max_parity_gap*2:.4f})"
        warnings.append(msg)
        print(f"  WARN — {msg}")
    else:
        print(f"  PASS")

    check_log["prediction_rate_parity"] = {
        "status": "WARN" if rate_gap > max_parity_gap * 2 else "PASS",
        "rate_by_region": {k: round(v, 4) for k, v in rate_by_region.items()},
        "rate_gap": round(rate_gap, 4),
    }

except Exception as e:
    print(f"  SKIP — {e}")
    check_log["prediction_rate_parity"] = {"status": "SKIP", "error": str(e)}

# COMMAND ----------
# MAGIC %md ## Final Compliance Decision

import json as _json

print("\n" + "="*60)
print("  COMPLIANCE CHECK SUMMARY")
print("="*60)
for check_name, result in check_log.items():
    status = result.get("status", "UNKNOWN")
    icon   = "✓" if status == "PASS" else ("⚠" if status in ("WARN", "SKIP") else "✗")
    print(f"  {icon} {check_name:35} [{status}]")

if warnings:
    print(f"\n  Warnings ({len(warnings)}):")
    for w in warnings:
        print(f"    ⚠ {w}")

mlflow.log_dict(check_log, "compliance/compliance_report.json")

if failures:
    client.set_model_version_tag(full_model_name, version, "compliance_status", "COMPLIANCE_FAILED")
    client.set_model_version_tag(full_model_name, version, "compliance_failures", _json.dumps(failures))
    print(f"\n  COMPLIANCE FAILED — blocking deploy_to_dev:")
    for f in failures:
        print(f"    ✗ {f}")
    raise ValueError(
        f"Compliance checks FAILED for {full_model_name} v{version}:\n" +
        "\n".join(f"  • {f}" for f in failures)
    )

client.set_model_version_tag(full_model_name, version, "compliance_status", "APPROVED")
client.set_model_version_tag(full_model_name, version, "compliance_warnings", _json.dumps(warnings))
print(f"\n  COMPLIANCE APPROVED — {full_model_name} v{version}")
print(f"  Warnings: {len(warnings)} | Failures: 0")
dbutils.jobs.taskValues.set("compliance_status", "APPROVED")
