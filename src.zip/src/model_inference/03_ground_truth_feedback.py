# Databricks notebook source
# MAGIC %md
# MAGIC # Ground Truth Feedback Loop
# MAGIC
# MAGIC **Position in pipeline:** runs daily at 09:00 UTC, after batch inference (06:00) and monitoring (07:00).
# MAGIC
# MAGIC ## What this notebook does
# MAGIC Closes the ML feedback loop by joining model predictions to actual outcomes:
# MAGIC
# MAGIC 1. Reads `churn_predictions` (what the model predicted for each customer)
# MAGIC 2. Reads `actual_outcomes` (did the customer actually churn? collected after 30 days)
# MAGIC 3. Joins on `customer_id` + date window to compute live evaluation metrics
# MAGIC 4. Writes results to `model_performance_actuals` (AUC, precision, recall, F1 on real data)
# MAGIC 5. Tags champion model version with `live_auc` in Unity Catalog
# MAGIC 6. Raises alert and triggers retraining if live AUC falls below threshold
# MAGIC
# MAGIC ## Why this is Level 3 critical
# MAGIC Training-time AUC is computed on held-out historical data.
# MAGIC Live AUC is computed on *real production predictions vs real outcomes*.
# MAGIC These diverge when: population shifts, data pipeline changes, concept drift occurs.
# MAGIC Without live AUC, you are flying blind — your model could be degrading silently.
# MAGIC
# MAGIC ## actual_outcomes table
# MAGIC Source: upstream CRM / event stream writes a row per customer per period.
# MAGIC Schema: customer_id STRING, actual_churn INT (0/1), outcome_date DATE, source STRING
# MAGIC Outcome is collected 30 days after scoring (sufficient for monthly churn labels).
# MAGIC
# MAGIC **Cost:** Single-node SPOT m5.large. Delta join + sklearn metrics on collected sample.

# COMMAND ----------
dbutils.widgets.text("catalog",               "dev_catalog")
dbutils.widgets.text("schema",                "mlops_demo")
dbutils.widgets.text("model_name",            "churn_classifier")
dbutils.widgets.text("outcome_lag_days",      "30")   # actuals available N days after scoring
dbutils.widgets.text("lookback_days",         "90")   # how many days of history to evaluate
dbutils.widgets.text("live_auc_threshold",    "0.68") # below this → retrain alert (looser than training gate)
dbutils.widgets.text("min_sample_size",       "200")  # skip if too few matched actuals

catalog            = dbutils.widgets.get("catalog")
schema             = dbutils.widgets.get("schema")
model_name         = dbutils.widgets.get("model_name")
outcome_lag_days   = int(dbutils.widgets.get("outcome_lag_days"))
lookback_days      = int(dbutils.widgets.get("lookback_days"))
live_auc_threshold = float(dbutils.widgets.get("live_auc_threshold"))
min_sample_size    = int(dbutils.widgets.get("min_sample_size"))

import json
import datetime
import urllib.request
import mlflow
import pandas as pd
import numpy as np
from mlflow import MlflowClient
from pyspark.sql import SparkSession, functions as F
from sklearn.metrics import (
    roc_auc_score,
    precision_score,
    recall_score,
    f1_score,
    average_precision_score,
)

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
spark  = SparkSession.builder.getOrCreate()

predictions_table    = f"{catalog}.{schema}.churn_predictions"
actual_outcomes_tbl  = f"{catalog}.{schema}.actual_outcomes"
performance_tbl      = f"{catalog}.{schema}.model_performance_actuals"
full_model_name      = f"{catalog}.{schema}.{model_name}"

# COMMAND ----------
# MAGIC %md ## 1. Ensure actual_outcomes Table Exists
# MAGIC
# MAGIC This table is populated by the upstream CRM / data pipeline.
# MAGIC We create it here with the correct schema if it does not exist yet.
# MAGIC On first run with no actuals, the notebook exits gracefully.

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {actual_outcomes_tbl} (
        customer_id   STRING  NOT NULL,
        actual_churn  INT     NOT NULL COMMENT '1 = churned, 0 = retained',
        outcome_date  DATE    NOT NULL COMMENT 'Date the outcome was observed',
        source        STRING  COMMENT 'CRM, event-stream, manual',
        loaded_at     TIMESTAMP
    )
    USING DELTA
    COMMENT 'Actual churn outcomes — joined to churn_predictions for live AUC evaluation'
    TBLPROPERTIES (
        'delta.enableChangeDataFeed'  = 'true',
        'delta.enableDeletionVectors' = 'true'
    )
""")
print(f"✓ {actual_outcomes_tbl} ready")

# COMMAND ----------
# MAGIC %md ## 2. Ensure model_performance_actuals Table Exists

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {performance_tbl} (
        model_version        STRING    NOT NULL,
        model_uri            STRING,
        scored_date          DATE      NOT NULL,
        live_auc             DOUBLE,
        live_pr_auc          DOUBLE,
        live_precision       DOUBLE,
        live_recall          DOUBLE,
        live_f1              DOUBLE,
        actual_positive_rate DOUBLE    COMMENT 'Fraction of customers who actually churned',
        pred_positive_rate   DOUBLE    COMMENT 'Fraction predicted as churn',
        sample_count         LONG,
        computed_at          TIMESTAMP
    )
    USING DELTA
    COMMENT 'Live model performance computed from ground truth feedback'
    TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")
print(f"✓ {performance_tbl} ready")

# COMMAND ----------
# MAGIC %md ## 3. Join Predictions to Actuals
# MAGIC
# MAGIC Match logic:
# MAGIC - Prediction scored_date falls in the evaluation window
# MAGIC - Outcome is available (outcome_date = scored_date + outcome_lag_days ± 2 days tolerance)
# MAGIC - Evaluates the **champion** model URI (current production model)
# MAGIC
# MAGIC Only scores within the actuals availability window are evaluated
# MAGIC (predictions from last `outcome_lag_days` days do not yet have actuals).

champion_mv  = client.get_model_version_by_alias(full_model_name, "champion")
champion_uri = f"models:/{full_model_name}@champion"

# Evaluation window: predictions that are old enough to have actuals
eval_end_date   = datetime.date.today() - datetime.timedelta(days=outcome_lag_days)
eval_start_date = eval_end_date - datetime.timedelta(days=lookback_days)

print(f"Champion:          {full_model_name} v{champion_mv.version}")
print(f"Evaluation window: {eval_start_date} → {eval_end_date}")

predictions_df = (
    spark.table(predictions_table)
    .filter(
        (F.col("model_uri") == F.lit(champion_uri)) &
        (F.to_date("scored_at") >= F.lit(str(eval_start_date))) &
        (F.to_date("scored_at") <= F.lit(str(eval_end_date)))
    )
    .select(
        "customer_id",
        F.col("churn_probability").alias("pred_prob"),
        F.col("churn_label").alias("pred_label"),
        F.to_date("scored_at").alias("scored_date"),
    )
)

actuals_df = (
    spark.table(actual_outcomes_tbl)
    .select("customer_id", "actual_churn", "outcome_date")
)

joined_df = (
    predictions_df
    .join(actuals_df, on="customer_id", how="inner")
    # Outcomes observed within [outcome_lag - 2, outcome_lag + 2] days of scoring
    .filter(
        (F.datediff("outcome_date", "scored_date") >= outcome_lag_days - 2) &
        (F.datediff("outcome_date", "scored_date") <= outcome_lag_days + 2)
    )
    .dropDuplicates(["customer_id", "scored_date"])
    .cache()
)

n_matched = joined_df.count()
print(f"Matched predictions ↔ actuals: {n_matched:,} rows")

if n_matched < min_sample_size:
    joined_df.unpersist()
    print(f"⚠ Fewer than {min_sample_size} matched samples — skipping metric computation.")
    print("  This is expected on first deploy or when actuals pipeline is new.")
    dbutils.notebook.exit("INSUFFICIENT_ACTUALS")

# COMMAND ----------
# MAGIC %md ## 4. Compute Live Metrics Per Day
# MAGIC
# MAGIC Compute AUC, PR-AUC, precision, recall, F1 for each scoring day.
# MAGIC This produces a time series of live performance — visible in monitoring dashboards.

scored_dates = [r["scored_date"] for r in joined_df.select("scored_date").distinct().orderBy("scored_date").collect()]
print(f"\nComputing live metrics for {len(scored_dates)} scoring days...")

daily_records = []

for scored_date in scored_dates:
    day_pdf = (
        joined_df
        .filter(F.col("scored_date") == F.lit(str(scored_date)))
        .select("pred_prob", "pred_label", "actual_churn")
        .toPandas()
    )
    if len(day_pdf) < 10 or day_pdf["actual_churn"].nunique() < 2:
        continue  # skip days with too few samples or single-class actuals

    y_true = day_pdf["actual_churn"].values
    y_prob  = day_pdf["pred_prob"].values
    y_pred  = day_pdf["pred_label"].values

    try:
        live_auc      = float(roc_auc_score(y_true, y_prob))
        live_pr_auc   = float(average_precision_score(y_true, y_prob))
        live_precision= float(precision_score(y_true, y_pred, zero_division=0))
        live_recall   = float(recall_score(y_true, y_pred, zero_division=0))
        live_f1       = float(f1_score(y_true, y_pred, zero_division=0))
        actual_pos_r  = float(y_true.mean())
        pred_pos_r    = float(y_pred.mean())

        print(f"  {scored_date}  AUC={live_auc:.4f}  PR-AUC={live_pr_auc:.4f}  "
              f"P={live_precision:.3f}  R={live_recall:.3f}  F1={live_f1:.3f}  "
              f"n={len(day_pdf):,}  actual_pos={actual_pos_r:.3f}")

        daily_records.append({
            "model_version":        champion_mv.version,
            "model_uri":            champion_uri,
            "scored_date":          scored_date,
            "live_auc":             live_auc,
            "live_pr_auc":          live_pr_auc,
            "live_precision":       live_precision,
            "live_recall":          live_recall,
            "live_f1":              live_f1,
            "actual_positive_rate": actual_pos_r,
            "pred_positive_rate":   pred_pos_r,
            "sample_count":         len(day_pdf),
            "computed_at":          pd.Timestamp.utcnow(),
        })
    except Exception as e:
        print(f"  {scored_date}: metric computation failed — {e}")

joined_df.unpersist()

if not daily_records:
    print("⚠ No valid daily records produced — skipping write.")
    dbutils.notebook.exit("NO_VALID_RECORDS")

# COMMAND ----------
# MAGIC %md ## 5. Write Daily Performance Records to Delta

perf_pdf = pd.DataFrame(daily_records)
(
    spark.createDataFrame(perf_pdf)
    .write.format("delta")
    .mode("append")
    .option("mergeSchema", True)
    .saveAsTable(performance_tbl)
)
print(f"\n✓ {len(daily_records)} records written → {performance_tbl}")

# COMMAND ----------
# MAGIC %md ## 6. Compute Rolling Live AUC (7-day average) for Champion Tagging

rolling_auc_row = spark.sql(f"""
    SELECT
        AVG(live_auc)            AS rolling_live_auc,
        AVG(actual_positive_rate) AS avg_actual_positive_rate,
        SUM(sample_count)        AS total_samples,
        MAX(scored_date)         AS latest_scored_date
    FROM {performance_tbl}
    WHERE model_version = '{champion_mv.version}'
      AND scored_date >= current_date() - 7
""").collect()[0]

rolling_live_auc     = float(rolling_auc_row["rolling_live_auc"] or 0.0)
avg_actual_pos_rate  = float(rolling_auc_row["avg_actual_positive_rate"] or 0.0)
total_samples        = int(rolling_auc_row["total_samples"] or 0)
latest_scored_date   = rolling_auc_row["latest_scored_date"]

print(f"\n7-day rolling live AUC:       {rolling_live_auc:.4f}")
print(f"Average actual positive rate: {avg_actual_pos_rate:.3f}")
print(f"Total matched samples:        {total_samples:,}")

# COMMAND ----------
# MAGIC %md ## 7. Tag Champion Model Version with Live AUC

client.set_model_version_tag(
    full_model_name, champion_mv.version,
    "live_auc_7d",           f"{rolling_live_auc:.4f}"
)
client.set_model_version_tag(
    full_model_name, champion_mv.version,
    "live_auc_updated_at",   datetime.datetime.utcnow().isoformat()
)
client.set_model_version_tag(
    full_model_name, champion_mv.version,
    "actual_positive_rate",  f"{avg_actual_pos_rate:.4f}"
)
print(f"✓ live_auc_7d={rolling_live_auc:.4f} tagged on {full_model_name} v{champion_mv.version}")

# COMMAND ----------
# MAGIC %md ## 8. Alert + Retraining Trigger if Live AUC Below Threshold

def _send_slack(webhook_url: str, message: str, env: str) -> None:
    payload = json.dumps({
        "text": f":warning: *Ground Truth Alert [{env.upper()}]*\n{message}",
        "username": "MLOps Ground Truth",
    }).encode()
    req = urllib.request.Request(
        webhook_url, data=payload,
        headers={"Content-Type": "application/json"}, method="POST"
    )
    urllib.request.urlopen(req, timeout=10)

try:
    slack_url = dbutils.secrets.get(scope="mlops-alerts", key="slack_webhook_url")
except Exception:
    slack_url = None

env_name = catalog.replace("_catalog", "")

if rolling_live_auc < live_auc_threshold and total_samples >= min_sample_size:
    msg = (
        f"Live AUC *{rolling_live_auc:.4f}* below threshold *{live_auc_threshold}*\n"
        f"  Champion: {full_model_name} v{champion_mv.version}\n"
        f"  Samples:  {total_samples:,} (last 7 days)\n"
        f"  Actual positive rate: {avg_actual_pos_rate:.3f}\n"
        f"  Action: *Retraining triggered*"
    )
    print(f"\n⚠  LIVE AUC ALERT: {msg}")

    # Log retraining trigger
    spark.createDataFrame([{
        "trigger_timestamp": datetime.datetime.utcnow(),
        "trigger_reason":    f"live_auc_below_threshold_{rolling_live_auc:.4f}",
        "triggered_by":      "ground_truth_feedback",
        "job_run_id":        None,
        "status":            "RETRAIN_TRIGGERED",
        "canary_traffic_pct": 0,
        "champion_version":   champion_mv.version,
        "challenger_version": "pending",
        "canary_start_ts":    None,
    }]).write.mode("append").option("mergeSchema", True).saveAsTable(
        f"{catalog}.{schema}.retraining_trigger_log"
    )

    if slack_url:
        _send_slack(slack_url, msg, env_name)
        print("✓ Slack alert sent")

    raise Exception(f"Live AUC {rolling_live_auc:.4f} below threshold {live_auc_threshold} — retraining required")

else:
    print(f"\n✓ Ground truth feedback complete — live AUC {rolling_live_auc:.4f} above threshold {live_auc_threshold}")

# COMMAND ----------
# MAGIC %md ## 9. Summary

print("\n" + "="*65)
print(f"  GROUND TRUTH FEEDBACK — COMPLETE")
print("="*65)
print(f"  Champion        : {full_model_name} v{champion_mv.version}")
print(f"  Eval window     : {eval_start_date} → {eval_end_date}")
print(f"  Days evaluated  : {len(daily_records)}")
print(f"  Total samples   : {total_samples:,}")
print(f"  7d Rolling AUC  : {rolling_live_auc:.4f}")
print(f"  Actual pos rate : {avg_actual_pos_rate:.3f}")
print(f"  AUC threshold   : {live_auc_threshold}  [{'PASS' if rolling_live_auc >= live_auc_threshold else 'FAIL'}]")
print(f"  Wrote to        : {performance_tbl}")
print("="*65)
