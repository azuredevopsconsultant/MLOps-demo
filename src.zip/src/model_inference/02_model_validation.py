# Databricks notebook source
# MAGIC %md
# MAGIC # Model Validation — Pre-Deployment Compliance Checks
# MAGIC Loads the challenger model, runs validation checks, and assigns the "challenger" alias
# MAGIC only when all gates pass. Called as a task in the model_training_job pipeline.

# COMMAND ----------
dbutils.widgets.text("catalog",        "dev_catalog")
dbutils.widgets.text("schema",         "mlops_demo")
dbutils.widgets.text("model_name",     "churn_classifier")
dbutils.widgets.text("min_auc",        "0.75")
dbutils.widgets.text("min_precision",  "0.60")
dbutils.widgets.text("min_recall",     "0.55")

catalog       = dbutils.widgets.get("catalog")
schema        = dbutils.widgets.get("schema")
model_name    = dbutils.widgets.get("model_name")
min_auc       = float(dbutils.widgets.get("min_auc"))
min_precision = float(dbutils.widgets.get("min_precision"))
min_recall    = float(dbutils.widgets.get("min_recall"))

import mlflow
from mlflow import MlflowClient
from databricks.feature_engineering import FeatureEngineeringClient
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score
import pandas as pd

mlflow.set_registry_uri("databricks-uc")
client = MlflowClient()
fe     = FeatureEngineeringClient()

full_model_name = f"{catalog}.{schema}.{model_name}"

# COMMAND ----------
# MAGIC %md ## Retrieve run from upstream training task

run_id = dbutils.jobs.taskValues.get(taskKey="train_model", key="run_id")
print(f"Validating run: {run_id}")

client.set_model_version_tag(
    name=full_model_name,
    version=dbutils.jobs.taskValues.get(taskKey="register_model", key="version", debugValue="1"),
    key="model_validation_status",
    value="PENDING",
)

# COMMAND ----------
# MAGIC %md ## Load held-out validation set

validation_df = (
    spark.table(f"{catalog}.{schema}.gold_customers_ml")
    .filter("split = 'validation'")
    .select("customer_id", "label")
)

if validation_df.count() == 0:
    # Fall back: sample 20% of gold table if no dedicated split column
    full_df = spark.table(f"{catalog}.{schema}.gold_customers_ml").select("customer_id", "label")
    validation_df = full_df.sample(fraction=0.2, seed=99)

print(f"Validation rows: {validation_df.count():,}")

# COMMAND ----------
# MAGIC %md ## Score with challenger model via Feature Store

model_uri    = f"runs:/{run_id}/model"
predictions  = fe.score_batch(model_uri=model_uri, df=validation_df)
pred_pd      = predictions.select("customer_id", "prediction", "label").toPandas()

y_true  = pred_pd["label"].astype(int)
y_proba = pred_pd["prediction"].astype(float)
y_pred  = (y_proba >= 0.5).astype(int)

metrics = {
    "val_roc_auc":   roc_auc_score(y_true, y_proba),
    "val_precision": precision_score(y_true, y_pred, zero_division=0),
    "val_recall":    recall_score(y_true, y_pred, zero_division=0),
    "val_f1":        f1_score(y_true, y_pred, zero_division=0),
}

for k, v in metrics.items():
    print(f"{k:20}: {v:.4f}")

# COMMAND ----------
# MAGIC %md ## Gate checks — block registration if any threshold fails

failures = []

if metrics["val_roc_auc"] < min_auc:
    failures.append(f"AUC {metrics['val_roc_auc']:.4f} < {min_auc}")

if metrics["val_precision"] < min_precision:
    failures.append(f"Precision {metrics['val_precision']:.4f} < {min_precision}")

if metrics["val_recall"] < min_recall:
    failures.append(f"Recall {metrics['val_recall']:.4f} < {min_recall}")

version = dbutils.jobs.taskValues.get(taskKey="register_model", key="version", debugValue="1")

if failures:
    client.set_model_version_tag(full_model_name, version, "model_validation_status", "FAILED")
    raise ValueError(
        f"Validation FAILED for {full_model_name} v{version}:\n" + "\n".join(f"  • {f}" for f in failures)
    )

# COMMAND ----------
# MAGIC %md ## All checks passed — tag and assign challenger alias

client.set_model_version_tag(full_model_name, version, "model_validation_status", "PASSED")
client.set_model_version_tag(full_model_name, version, "val_auc",       str(round(metrics["val_roc_auc"], 4)))
client.set_model_version_tag(full_model_name, version, "val_precision", str(round(metrics["val_precision"], 4)))
client.set_model_version_tag(full_model_name, version, "val_recall",    str(round(metrics["val_recall"], 4)))

client.set_registered_model_alias(
    name=full_model_name,
    alias="challenger",
    version=version,
)

print(f"\n✓ Validation PASSED — {full_model_name} v{version} aliased as 'challenger'")
print(f"  AUC={metrics['val_roc_auc']:.4f} | Precision={metrics['val_precision']:.4f} | Recall={metrics['val_recall']:.4f}")

dbutils.jobs.taskValues.set("validation_status", "PASSED")
dbutils.jobs.taskValues.set("val_auc", str(round(metrics["val_roc_auc"], 4)))
