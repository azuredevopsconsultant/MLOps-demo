# Databricks notebook source
# MAGIC %md
# MAGIC # Batch Inference — Scheduled Scoring Pipeline
# MAGIC Loads the champion model and scores the full customer population daily.

# COMMAND ----------
dbutils.widgets.text("catalog",       "dev_catalog")
dbutils.widgets.text("schema",        "mlops_demo")
dbutils.widgets.text("model_name",    "churn_classifier")
dbutils.widgets.text("model_alias",   "champion")

catalog      = dbutils.widgets.get("catalog")
schema       = dbutils.widgets.get("schema")
model_name   = dbutils.widgets.get("model_name")
model_alias  = dbutils.widgets.get("model_alias")

import mlflow
from databricks.feature_engineering import FeatureEngineeringClient
from pyspark.sql import functions as F

mlflow.set_registry_uri("databricks-uc")
fe = FeatureEngineeringClient()

full_model_name = f"{catalog}.{schema}.{model_name}"
model_uri       = f"models:/{full_model_name}@{model_alias}"
predictions_tbl = f"{catalog}.{schema}.churn_predictions"

# COMMAND ----------
# MAGIC %md ## Load scoring population and run inference

scoring_df = (
    spark.table(f"{catalog}.{schema}.silver_customers")
    .select("customer_id")
    .distinct()
)

print(f"Scoring {scoring_df.count():,} customers with {full_model_name}@{model_alias}")

# Feature lookup keeps training/serving consistent automatically
predictions = fe.score_batch(
    model_uri=model_uri,
    df=scoring_df,
)

# COMMAND ----------
# MAGIC %md ## Write predictions to Delta table
# MAGIC
# MAGIC Uses dynamic partition overwrite on `scored_date` so each daily run
# MAGIC only replaces its own partition — historical predictions stay intact
# MAGIC for the ground truth feedback loop (03_ground_truth_feedback.py).

spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS {predictions_tbl} (
        customer_id        STRING,
        churn_probability  DOUBLE,
        churn_label        INT,
        risk_tier          STRING,
        scored_at          TIMESTAMP,
        model_uri          STRING,
        scored_date        DATE
    )
    USING DELTA
    PARTITIONED BY (scored_date)
    TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true')
""")

output_df = (
    predictions
    .withColumn("churn_probability", F.col("prediction").cast("double"))
    .withColumn("churn_label",       (F.col("churn_probability") >= 0.5).cast("int"))
    .withColumn("risk_tier",
        F.when(F.col("churn_probability") >= 0.75, "high")
         .when(F.col("churn_probability") >= 0.50, "medium")
         .otherwise("low")
    )
    .withColumn("scored_at",   F.current_timestamp())
    .withColumn("model_uri",   F.lit(model_uri))
    .withColumn("scored_date", F.to_date(F.current_timestamp()))
    .select("customer_id", "churn_probability", "churn_label",
            "risk_tier", "scored_at", "model_uri", "scored_date")
)

(
    output_df.write
    .format("delta")
    .mode("overwrite")
    .partitionBy("scored_date")
    .saveAsTable(predictions_tbl)
)

# Summary stats
summary = output_df.groupBy("risk_tier").count().toPandas()
print(f"\n{'='*40}")
print(f"Predictions written → {predictions_tbl}")
print(summary.to_string(index=False))
