# Databricks notebook source
# MAGIC %md
# MAGIC # Unity Catalog Bootstrap
# MAGIC **Run this ONCE per environment before any pipeline job.**
# MAGIC
# MAGIC What this notebook does (all operations are idempotent):
# MAGIC 1. Create catalog and schema for the target environment
# MAGIC 2. Enable Delta features (Change Data Feed, Deletion Vectors) at catalog level
# MAGIC 3. Set catalog/schema ownership and comments
# MAGIC 4. Pre-create all pipeline tables with correct schemas and TBLPROPERTIES
# MAGIC 5. Verify Unity Catalog metastore connectivity
# MAGIC
# MAGIC **Prerequisites (done via Terraform before running this):**
# MAGIC - Metastore created and attached to the workspace
# MAGIC - Storage credential registered (IAM role)
# MAGIC - External locations created (S3 raw / processed / artifacts)
# MAGIC - Workspace admin account available

# COMMAND ----------
dbutils.widgets.text("catalog",      "dev_catalog")
dbutils.widgets.text("schema",       "mlops_demo")
dbutils.widgets.text("owner_group",  "mlops-platform-admins")
dbutils.widgets.text("location_prefix", "")  # e.g. s3://mlops-prod-123-processed-data/mlops_demo

catalog        = dbutils.widgets.get("catalog")
schema         = dbutils.widgets.get("schema")
owner_group    = dbutils.widgets.get("owner_group")
location_prefix = dbutils.widgets.get("location_prefix")

print(f"Bootstrap target: {catalog}.{schema}")
print(f"Owner group:      {owner_group}")

# COMMAND ----------
# MAGIC %md ## 1. Verify Unity Catalog Metastore

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

metastore_info = spark.sql("SELECT current_metastore()").collect()
print(f"Active metastore: {metastore_info[0][0]}")

current_user = spark.sql("SELECT current_user()").collect()[0][0]
print(f"Running as:       {current_user}")

# COMMAND ----------
# MAGIC %md ## 2. Create Catalog

spark.sql(f"""
    CREATE CATALOG IF NOT EXISTS `{catalog}`
    COMMENT 'MLOps churn prediction platform — {catalog}'
""")

spark.sql(f"USE CATALOG `{catalog}`")
print(f"✓ Catalog ready: {catalog}")

# Transfer ownership to admin group so pipelines don't depend on personal credentials.
spark.sql(f"ALTER CATALOG `{catalog}` OWNER TO `{owner_group}`")
print(f"✓ Ownership transferred to {owner_group}")

# COMMAND ----------
# MAGIC %md ## 3. Create Schema

location_clause = f"MANAGED LOCATION '{location_prefix}'" if location_prefix else ""

spark.sql(f"""
    CREATE SCHEMA IF NOT EXISTS `{catalog}`.`{schema}`
    {location_clause}
    COMMENT 'MLOps pipeline tables: bronze/silver/gold, features, predictions, monitoring logs'
""")

spark.sql(f"ALTER SCHEMA `{catalog}`.`{schema}` OWNER TO `{owner_group}`")
print(f"✓ Schema ready: {catalog}.{schema}")

# COMMAND ----------
# MAGIC %md ## 4. Pre-create Bronze Table

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.bronze_customers (
        customer_id        STRING  NOT NULL,
        age                INT,
        tenure_months      INT,
        monthly_spend      DOUBLE,
        product_tier       STRING,
        region             STRING,
        churn_flag         INT,
        ingestion_timestamp TIMESTAMP,
        source_file        STRING
    )
    USING delta
    TBLPROPERTIES (
        'delta.enableChangeDataFeed'    = 'true',
        'delta.enableDeletionVectors'   = 'true',
        'delta.autoOptimize.optimizeWrite' = 'true',
        'delta.autoOptimize.autoCompact'   = 'true'
    )
    COMMENT 'Raw customer records ingested via Autoloader from S3. PII present — access restricted to platform-admins and ml-engineers.'
""")
print(f"✓ bronze_customers")

# COMMAND ----------
# MAGIC %md ## 5. Pre-create Silver Table

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.silver_customers (
        customer_id        STRING  NOT NULL,
        age                INT,
        tenure_months      INT,
        monthly_spend      DOUBLE,
        product_tier       STRING,
        region             STRING,
        churn_flag         INT,
        processed_at       TIMESTAMP
    )
    USING delta
    TBLPROPERTIES (
        'delta.enableChangeDataFeed'    = 'true',
        'delta.enableDeletionVectors'   = 'true',
        'delta.autoOptimize.optimizeWrite' = 'true',
        'delta.autoOptimize.autoCompact'   = 'true'
    )
    COMMENT 'Cleansed, quality-gated customer records. PII masked for non-admin groups.'
""")
print(f"✓ silver_customers")

# COMMAND ----------
# MAGIC %md ## 6. Pre-create Gold Table

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.gold_customers_ml (
        customer_id        STRING  NOT NULL,
        age                INT,
        tenure_months      INT,
        monthly_spend      DOUBLE,
        product_tier       STRING,
        region             STRING,
        churn_flag         INT,
        spend_12m_avg      DOUBLE,
        is_high_value      INT,
        region_encoded     BIGINT,
        tier_encoded       INT,
        label              INT,
        gold_created_at    TIMESTAMP
    )
    USING delta
    TBLPROPERTIES (
        'delta.enableChangeDataFeed'    = 'true',
        'delta.enableDeletionVectors'   = 'true',
        'delta.autoOptimize.optimizeWrite' = 'true',
        'delta.autoOptimize.autoCompact'   = 'true'
    )
    COMMENT 'ML-ready customer dataset. Curated for churn prediction. Updated daily.'
""")
print(f"✓ gold_customers_ml")

# COMMAND ----------
# MAGIC %md ## 7. Pre-create Predictions Table

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.churn_predictions (
        customer_id         STRING  NOT NULL,
        churn_probability   DOUBLE,
        churn_label         INT,
        risk_tier           STRING,
        model_uri           STRING,
        scored_at           TIMESTAMP
    )
    USING delta
    TBLPROPERTIES (
        'delta.enableChangeDataFeed'  = 'true',
        'delta.enableDeletionVectors' = 'true'
    )
    COMMENT 'Daily batch predictions from the champion model.'
""")
print(f"✓ churn_predictions")

# COMMAND ----------
# MAGIC %md ## 8. Pre-create Monitoring Log Tables

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.model_monitoring_log (
        check_timestamp    TIMESTAMP NOT NULL,
        check_type         STRING,
        metric_name        STRING,
        metric_value       DOUBLE,
        threshold          DOUBLE,
        status             STRING,
        drift_alert        BOOLEAN,
        perf_alert         STRING,
        details            STRING
    )
    USING delta
    TBLPROPERTIES ('delta.enableDeletionVectors' = 'true')
    COMMENT 'Drift, performance, freshness, and completeness monitoring results.'
""")
print(f"✓ model_monitoring_log")

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.operational_monitoring_log (
        check_timestamp    TIMESTAMP NOT NULL,
        job_name           STRING,
        success_rate       DOUBLE,
        avg_duration_mins  DOUBLE,
        p95_duration_mins  DOUBLE,
        failure_count      INT,
        dbu_cost           DOUBLE,
        alert_triggered    BOOLEAN
    )
    USING delta
    TBLPROPERTIES ('delta.enableDeletionVectors' = 'true')
    COMMENT 'Job success rates, execution times, and DBU costs.'
""")
print(f"✓ operational_monitoring_log")

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.serving_health_log (
        check_timestamp    TIMESTAMP NOT NULL,
        endpoint_name      STRING,
        p50_latency_ms     DOUBLE,
        p95_latency_ms     DOUBLE,
        error_rate         DOUBLE,
        failover_triggered BOOLEAN,
        status             STRING
    )
    USING delta
    TBLPROPERTIES ('delta.enableDeletionVectors' = 'true')
    COMMENT 'Serving endpoint latency probes and failover events.'
""")
print(f"✓ serving_health_log")

spark.sql(f"""
    CREATE TABLE IF NOT EXISTS `{catalog}`.`{schema}`.retraining_trigger_log (
        trigger_timestamp  TIMESTAMP NOT NULL,
        trigger_reason     STRING,
        triggered_by       STRING,
        job_run_id         LONG,
        status             STRING
    )
    USING delta
    TBLPROPERTIES ('delta.enableDeletionVectors' = 'true')
    COMMENT 'Retraining trigger events — drift-triggered and scheduled.'
""")
print(f"✓ retraining_trigger_log")

# COMMAND ----------
# MAGIC %md ## 9. Verify All Tables

tables = spark.sql(f"SHOW TABLES IN `{catalog}`.`{schema}`").collect()
print(f"\n{catalog}.{schema} contains {len(tables)} tables:")
for t in tables:
    print(f"  ✓ {t['tableName']}")

# COMMAND ----------
# MAGIC %md ## 10. Final Verification

print("=" * 60)
print(f"  Bootstrap complete for: {catalog}.{schema}")
print("=" * 60)
print()
print("  Next steps:")
print("  1. Run governance_job to apply RBAC grants")
print("  2. Run data_ingestion_job to populate bronze/silver/gold")
print("  3. Run feature_engineering_job to compute feature store")
print("  4. Run model_training_job to train + register first model")
print("  5. Run promote_model.py to set champion alias")
print("  6. Enable scheduled jobs in databricks.yml")
print()
print("  Verify external locations are accessible:")
spark.sql(f"SHOW EXTERNAL LOCATIONS").show(10, truncate=False)
