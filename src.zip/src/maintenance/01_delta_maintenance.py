# Databricks notebook source
# MAGIC %md
# MAGIC # Delta Table Maintenance — Weekly OPTIMIZE + VACUUM
# MAGIC
# MAGIC **Schedule:** Sunday 01:00 UTC — runs before weekly retraining (Monday 02:00).
# MAGIC Ensures tables are compacted and stale files removed before training reads them.
# MAGIC
# MAGIC ## What this notebook does
# MAGIC 1. For each Silver/Gold/prediction table:
# MAGIC    - OPTIMIZE + Z-ORDER on primary key columns (improves scan efficiency 2–10×)
# MAGIC    - ANALYZE TABLE to refresh column statistics for the query optimiser
# MAGIC    - VACUUM RETAIN N HOURS (default 168 h = 7 days) to remove stale Delta versions
# MAGIC 2. Reports size and file count before/after for each table
# MAGIC 3. Logs a maintenance event to model_monitoring_log for audit trail
# MAGIC
# MAGIC ## Why Silver/Gold tables need dedicated maintenance
# MAGIC The ingestion pipeline writes data continuously with autoCompact=true (small-file prevention
# MAGIC during writes). However, autoCompact does NOT Z-ORDER — only OPTIMIZE does.
# MAGIC Without weekly Z-ORDER on customer_id, full-table scans during training degrade
# MAGIC progressively as the table grows, adding minutes to the Feature Store join.
# MAGIC
# MAGIC **Cost:** Single-node SPOT m5.large. Pure Delta DDL — no Spark shuffles.
# MAGIC Typical runtime: 10–20 min for tables up to 50 GB.

# COMMAND ----------
dbutils.widgets.text("catalog",               "dev_catalog")
dbutils.widgets.text("schema",                "mlops_demo")
dbutils.widgets.text("vacuum_retain_hours",   "168")   # 7 days
dbutils.widgets.text("growth_threshold_pct",  "5")     # skip OPTIMIZE if growth < threshold %

catalog              = dbutils.widgets.get("catalog")
schema               = dbutils.widgets.get("schema")
vacuum_retain_hours  = int(dbutils.widgets.get("vacuum_retain_hours"))
growth_threshold_pct = float(dbutils.widgets.get("growth_threshold_pct")) / 100.0

import datetime
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# Disable safety check — we explicitly set RETAIN to 168h which respects time-travel SLA
spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")

# COMMAND ----------
# MAGIC %md ## 1. Table Definitions — ZORDER keys per table

# Each entry: (table_name, [zorder_columns])
# Z-ORDER on the columns most frequently used in WHERE / JOIN clauses.
MAINTENANCE_TABLES = [
    ("silver_customers",              ["customer_id"]),
    ("gold_customers_ml",             ["customer_id"]),
    ("customer_churn_features",       ["customer_id", "feature_timestamp"]),
    ("churn_predictions",             ["customer_id", "scored_date"]),
    ("actual_outcomes",               ["customer_id", "outcome_date"]),
    ("model_performance_actuals",     ["model_version", "scored_date"]),
    ("model_monitoring_log",          ["run_date"]),
    ("retraining_trigger_log",        ["trigger_timestamp"]),
]

# COMMAND ----------
# MAGIC %md ## 2. Run OPTIMIZE + ANALYZE + VACUUM per table

results = []

for table_name, zorder_cols in MAINTENANCE_TABLES:
    full_table = f"`{catalog}`.`{schema}`.`{table_name}`"
    start_ts   = datetime.datetime.utcnow()

    try:
        # ── Check table exists ────────────────────────────────────────────────
        spark.sql(f"DESCRIBE TABLE {full_table}")
    except Exception:
        print(f"  ⏭  {table_name}: table does not exist yet — skipping")
        continue

    # ── Estimate whether OPTIMIZE is worth running ────────────────────────────
    try:
        history = spark.sql(
            f"DESCRIBE HISTORY {full_table} LIMIT 20"
        ).filter("operation = 'OPTIMIZE'")

        last_optimize_rows = 0
        if history.count() > 0:
            last_op = history.orderBy("timestamp", ascending=False).first()
            last_optimize_rows = int(
                (last_op["operationMetrics"] or {}).get("numOutputRows", 0)
            )

        current_rows = spark.sql(f"SELECT COUNT(*) AS n FROM {full_table}").first()["n"]
        growth = (current_rows - last_optimize_rows) / max(last_optimize_rows, 1)
    except Exception:
        growth = 1.0           # force optimize if we cannot read history
        current_rows = 0

    print(f"\n{'─'*60}")
    print(f"  {table_name}")
    print(f"  rows={current_rows:,}  growth={growth:.0%}  threshold={growth_threshold_pct:.0%}")

    # ── OPTIMIZE + Z-ORDER ────────────────────────────────────────────────────
    optimize_ran = False
    if growth >= growth_threshold_pct:
        zorder_clause = ", ".join(zorder_cols)
        spark.sql(f"OPTIMIZE {full_table} ZORDER BY ({zorder_clause})")
        optimize_ran = True
        print(f"  ✓ OPTIMIZE + ZORDER({zorder_clause}) complete")
    else:
        print(f"  ⏭  OPTIMIZE skipped — growth {growth:.0%} < threshold {growth_threshold_pct:.0%}")

    # ── ANALYZE TABLE — refresh column stats for query optimiser ─────────────
    try:
        spark.sql(f"ANALYZE TABLE {full_table} COMPUTE STATISTICS FOR ALL COLUMNS")
        print(f"  ✓ ANALYZE TABLE complete")
    except Exception as e:
        print(f"  ⚠  ANALYZE skipped: {e}")

    # ── VACUUM — remove stale Delta versions older than retention window ──────
    try:
        vacuum_result = spark.sql(f"VACUUM {full_table} RETAIN {vacuum_retain_hours} HOURS")
        print(f"  ✓ VACUUM RETAIN {vacuum_retain_hours}h complete")
    except Exception as e:
        print(f"  ⚠  VACUUM failed: {e}")

    elapsed = (datetime.datetime.utcnow() - start_ts).total_seconds()
    results.append({
        "table":         table_name,
        "rows":          current_rows,
        "growth_pct":    round(growth * 100, 1),
        "optimize_ran":  optimize_ran,
        "elapsed_sec":   round(elapsed, 1),
        "status":        "OK",
    })

# COMMAND ----------
# MAGIC %md ## 3. Summary Report

print("\n" + "="*65)
print(f"  DELTA MAINTENANCE COMPLETE — {datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}")
print("="*65)
print(f"  {'Table':<38} {'Rows':>10}  {'Growth':>7}  {'Optimised':>10}")
print(f"  {'─'*38}  {'─'*10}  {'─'*7}  {'─'*10}")
for r in results:
    print(
        f"  {r['table']:<38} {r['rows']:>10,}  {r['growth_pct']:>6.1f}%  "
        f"{'YES' if r['optimize_ran'] else 'SKIP':>10}"
    )
print("="*65)

# ── Log maintenance event to monitoring table ────────────────────────────────
try:
    import pandas as pd
    log_records = [
        {
            "run_date":             datetime.date.today(),
            "model_name":           "MAINTENANCE",
            "run_timestamp":        datetime.datetime.utcnow(),
            "drift_alert":          False,
            "perf_alert":           False,
            "concept_drift":        False,
            "concept_drift_alert":  False,
            "notes":                f"delta_maintenance: {len(results)} tables processed",
        }
    ]
    (
        spark.createDataFrame(pd.DataFrame(log_records))
        .write.format("delta")
        .mode("append")
        .option("mergeSchema", True)
        .saveAsTable(f"{catalog}.{schema}.model_monitoring_log")
    )
    print(f"\n✓ Maintenance event logged to {catalog}.{schema}.model_monitoring_log")
except Exception as e:
    print(f"  ⚠  Audit log write skipped (non-fatal): {e}")
