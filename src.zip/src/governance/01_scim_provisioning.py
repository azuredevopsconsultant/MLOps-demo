# Databricks notebook source
# MAGIC %md
# MAGIC # Identity & Access Management — SCIM Provisioning
# MAGIC Syncs users and groups from your identity provider (Azure AD / Okta / SCIM IdP)
# MAGIC into Databricks, then applies Unity Catalog grants using least-privilege roles.
# MAGIC
# MAGIC ## How to configure automatic SCIM sync from IdP
# MAGIC Databricks SCIM is a **workspace-level setting** configured once:
# MAGIC
# MAGIC ```
# MAGIC 1. Azure AD:  Databricks workspace → Settings → Identity & Access → SCIM provisioning
# MAGIC              Azure AD Enterprise App → Provisioning → SCIM URL + Token
# MAGIC 2. Okta:      Similar — Databricks Okta app → Provisioning → SCIM 2.0 connector
# MAGIC 3. Token:     Generate via: databricks tokens create --comment "SCIM sync token"
# MAGIC ```
# MAGIC
# MAGIC This notebook handles the **group-to-catalog-grant mapping** that must be
# MAGIC maintained after SCIM syncs groups in.  Run it after any IdP group change.
# MAGIC
# MAGIC **Cost:** Pure SDK + SQL DDL calls — no cluster compute.  Runs on single-node SPOT.

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema",  "mlops_demo")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")

from databricks.sdk import WorkspaceClient
from databricks.sdk.service.iam import (
    Group,
    ComplexValue,
    PatchOp,
    PatchSchema,
    Patch,
)
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
w     = WorkspaceClient()

# COMMAND ----------
# MAGIC %md ## 1. Group Definitions
# MAGIC Map IdP group names → Unity Catalog privilege sets.
# MAGIC Adjust group names to match exactly what your IdP sends via SCIM.

GROUP_POLICY: dict[str, dict] = {
    "mlops-data-scientists": {
        "catalog_privileges":  ["USE CATALOG", "USE SCHEMA"],
        "schema_privileges":   ["SELECT", "CREATE TABLE"],
        "model_privileges":    ["USE CATALOG", "EXECUTE"],
        "description":         "Data scientists — read feature tables, run models",
    },
    "mlops-ml-engineers": {
        "catalog_privileges":  ["USE CATALOG", "USE SCHEMA"],
        "schema_privileges":   ["SELECT", "CREATE TABLE", "CREATE MODEL", "MODIFY"],
        "model_privileges":    ["USE CATALOG", "EXECUTE", "APPLY TAG"],
        "description":         "ML engineers — full schema access, register models",
    },
    "mlops-platform-admins": {
        "catalog_privileges":  ["ALL PRIVILEGES"],
        "schema_privileges":   [],   # inherited from catalog
        "model_privileges":    [],
        "description":         "Platform admins — full catalog ownership",
    },
    "mlops-read-only": {
        "catalog_privileges":  ["USE CATALOG", "USE SCHEMA"],
        "schema_privileges":   ["SELECT"],
        "model_privileges":    ["USE CATALOG", "EXECUTE"],
        "description":         "Analysts and auditors — read-only access",
    },
}

# COMMAND ----------
# MAGIC %md ## 2. Ensure Groups Exist in Databricks
# MAGIC SCIM provisioning creates groups automatically, but this step is a safety net:
# MAGIC create any missing groups before applying grants (idempotent).

existing_groups = {g.display_name: g for g in w.groups.list(attributes="displayName,id")}
print(f"Found {len(existing_groups)} existing workspace groups")

for group_name, policy in GROUP_POLICY.items():
    if group_name in existing_groups:
        group_id = existing_groups[group_name].id
        print(f"  ✓ exists  {group_name}  (id={group_id})")
    else:
        created = w.groups.create(
            display_name=group_name,
            meta={"resourceType": "Group"},
        )
        print(f"  + created {group_name}  (id={created.id})")

# COMMAND ----------
# MAGIC %md ## 3. Apply Unity Catalog Grants
# MAGIC Uses GRANT SQL DDL — idempotent (Databricks ignores duplicate grants).

def _grant(privilege: str, on_type: str, on_name: str, principal: str) -> None:
    spark.sql(f"GRANT {privilege} ON {on_type} `{on_name}` TO `{principal}`")

for group_name, policy in GROUP_POLICY.items():
    print(f"\n  Applying grants for: {group_name}")

    for priv in policy["catalog_privileges"]:
        if priv == "ALL PRIVILEGES":
            _grant("ALL PRIVILEGES", "CATALOG", catalog, group_name)
            print(f"    GRANT ALL PRIVILEGES ON CATALOG {catalog}")
        else:
            _grant(priv, "CATALOG", catalog, group_name)
            print(f"    GRANT {priv} ON CATALOG {catalog}")

    for priv in policy["schema_privileges"]:
        _grant(priv, "SCHEMA", f"{catalog}.{schema}", group_name)
        print(f"    GRANT {priv} ON SCHEMA {catalog}.{schema}")

    if policy["model_privileges"]:
        for priv in policy["model_privileges"]:
            _grant(priv, "CATALOG", catalog, group_name)

print("\n✓ All UC grants applied")

# COMMAND ----------
# MAGIC %md ## 4. Verify Grants — Audit Output

grants_df = spark.sql(f"SHOW GRANTS ON CATALOG `{catalog}`")
print(f"\nCurrent grants on {catalog}:")
grants_df.show(50, truncate=False)

schema_grants = spark.sql(f"SHOW GRANTS ON SCHEMA `{catalog}`.`{schema}`")
print(f"\nCurrent grants on {catalog}.{schema}:")
schema_grants.show(50, truncate=False)

# COMMAND ----------
# MAGIC %md ## 5. SCIM Token Setup Helper
# MAGIC Run this cell ONCE to display the SCIM endpoint URL for your IdP configuration.
# MAGIC Copy the URL + token into your IdP's SCIM connector settings.

workspace_host = w.config.host.rstrip("/")
scim_url       = f"{workspace_host}/api/2.0/preview/scim/v2"

print("=" * 70)
print("  SCIM Configuration for your Identity Provider")
print("=" * 70)
print(f"  SCIM endpoint URL : {scim_url}")
print(f"  Auth type         : Bearer token")
print(f"  Token             : Generate via:")
print(f"    databricks tokens create --comment 'SCIM IdP sync'")
print()
print("  Azure AD steps:")
print("    1. Azure Portal → Enterprise Applications → Databricks")
print("    2. Provisioning → Provisioning Mode = Automatic")
print("    3. Admin Credentials → Tenant URL = (SCIM URL above)")
print("    4. Admin Credentials → Secret Token = (token above)")
print("    5. Attribute Mappings → confirm userName, displayName, groups")
print("    6. Settings → Scope = Sync only assigned users and groups")
print("    7. Save → Test Connection → Start Provisioning")
print()
print("  Groups to assign in IdP:")
for g in GROUP_POLICY:
    print(f"    - {g}")
print("=" * 70)
