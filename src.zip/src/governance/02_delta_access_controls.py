# Databricks notebook source
# MAGIC %md
# MAGIC # Delta Table Access Controls — Least-Privilege Table Grants + Column Masking
# MAGIC Applies fine-grained table-level access controls on top of the schema-level
# MAGIC grants configured in `01_scim_provisioning.py`.
# MAGIC
# MAGIC ## Access model
# MAGIC | Group | Bronze | Silver | Gold | Features | Predictions | Models |
# MAGIC |---|---|---|---|---|---|---|
# MAGIC | mlops-platform-admins | ALL | ALL | ALL | ALL | ALL | ALL |
# MAGIC | mlops-ml-engineers | SELECT | SELECT+MODIFY | SELECT+MODIFY | SELECT+MODIFY | SELECT | EXECUTE |
# MAGIC | mlops-data-scientists | — | SELECT (masked) | SELECT | SELECT | SELECT | EXECUTE |
# MAGIC | mlops-read-only | — | — | SELECT | — | SELECT | — |
# MAGIC
# MAGIC ## Column masking (Level 3 — fully implemented)
# MAGIC PII columns `email` and `phone_number` in `silver_customers` are masked for all
# MAGIC non-admin groups using Unity Catalog SQL masking functions.
# MAGIC - **Admins:** see plain text values
# MAGIC - **ML Engineers + Data Scientists:** see partially masked values (e.g. j***@domain.com)
# MAGIC - **Read-only:** no access to silver_customers at all
# MAGIC
# MAGIC **Why Bronze is restricted:** Raw data contains unmasked PII before Silver masking.
# MAGIC **Cost:** Pure SQL DDL — no Spark compute. Runs on single-node SPOT m5.large.

# COMMAND ----------
dbutils.widgets.text("catalog", "dev_catalog")
dbutils.widgets.text("schema",  "mlops_demo")

catalog = dbutils.widgets.get("catalog")
schema  = dbutils.widgets.get("schema")

from pyspark.sql import SparkSession
spark = SparkSession.builder.getOrCreate()

# COMMAND ----------
# MAGIC %md ## 1. Create PII Masking Functions in Unity Catalog
# MAGIC
# MAGIC Unity Catalog masking functions must be created in the target catalog/schema.
# MAGIC They use `is_account_group_member()` to check the caller's group membership —
# MAGIC Unity Catalog enforces this transparently at query time.
# MAGIC
# MAGIC **email mask:** j***@example.com (preserve first char + domain)
# MAGIC **phone mask:** ***-***-1234 (preserve last 4 digits only)

# ── Email masking function ────────────────────────────────────────────────────
spark.sql(f"""
    CREATE OR REPLACE FUNCTION `{catalog}`.`{schema}`.pii_mask_email(email STRING)
    RETURNS STRING
    LANGUAGE SQL
    COMMENT 'Masks email for non-admins: j***@domain.com. Admins see full value.'
    RETURN CASE
        WHEN is_account_group_member('mlops-platform-admins') THEN email
        WHEN email IS NULL                                     THEN NULL
        ELSE
            concat(
                left(email, 1),
                '***',
                substring(email, locate('@', email))
            )
    END
""")
print(f"✓ pii_mask_email created in {catalog}.{schema}")

# ── Phone masking function ────────────────────────────────────────────────────
spark.sql(f"""
    CREATE OR REPLACE FUNCTION `{catalog}`.`{schema}`.pii_mask_phone(phone STRING)
    RETURNS STRING
    LANGUAGE SQL
    COMMENT 'Masks phone for non-admins: ***-***-1234. Admins see full value.'
    RETURN CASE
        WHEN is_account_group_member('mlops-platform-admins') THEN phone
        WHEN phone IS NULL                                     THEN NULL
        ELSE concat('***-***-', right(regexp_replace(phone, '[^0-9]', ''), 4))
    END
""")
print(f"✓ pii_mask_phone created in {catalog}.{schema}")

# COMMAND ----------
# MAGIC %md ## 2. Create Row Filter Function
# MAGIC
# MAGIC Row filter for silver_customers: restricts rows with unresolved PII flags.
# MAGIC Data scientists see all rows (column masking handles PII).
# MAGIC Platform admins bypass the filter entirely (see raw values + all rows).
# MAGIC
# MAGIC This is separate from column masking — it controls ROW visibility,
# MAGIC e.g. blocking rows flagged as "do not process" in the consent_status field.

spark.sql(f"""
    CREATE OR REPLACE FUNCTION `{catalog}`.`{schema}`.pii_row_filter(consent_status STRING)
    RETURNS BOOLEAN
    LANGUAGE SQL
    COMMENT 'Filters out rows where consent_status=WITHDRAWN for non-admins (GDPR erasure pending).'
    RETURN CASE
        WHEN is_account_group_member('mlops-platform-admins') THEN TRUE
        ELSE coalesce(consent_status, 'ACTIVE') != 'WITHDRAWN'
    END
""")
print(f"✓ pii_row_filter created in {catalog}.{schema}")

# COMMAND ----------
# MAGIC %md ## 3. Apply Column Masks to silver_customers
# MAGIC
# MAGIC Uses `ALTER TABLE ... ALTER COLUMN ... SET MASK` syntax.
# MAGIC The masking function is evaluated at query time — no data is physically changed.
# MAGIC Masks are transparent to existing write pipelines.

PII_COLUMN_MASKS = [
    ("silver_customers", "email",        f"`{catalog}`.`{schema}`.pii_mask_email"),
    ("silver_customers", "phone_number", f"`{catalog}`.`{schema}`.pii_mask_phone"),
]

for table, column, mask_fn in PII_COLUMN_MASKS:
    full_table = f"`{catalog}`.`{schema}`.`{table}`"
    try:
        spark.sql(f"""
            ALTER TABLE {full_table}
            ALTER COLUMN {column}
            SET MASK {mask_fn}
            USING COLUMNS ({column})
        """)
        print(f"  ✓ Column mask applied: {table}.{column} → {mask_fn.split('.')[-1]}")
    except Exception as e:
        print(f"  ⚠ Column mask skipped ({table}.{column}): {e}")
        print(f"    (Table may not exist yet — mask will be re-applied on next governance run)")

# COMMAND ----------
# MAGIC %md ## 4. Apply Row Filter to silver_customers

try:
    spark.sql(f"""
        ALTER TABLE `{catalog}`.`{schema}`.`silver_customers`
        SET ROW FILTER `{catalog}`.`{schema}`.pii_row_filter ON (consent_status)
    """)
    print("✓ Row filter applied to silver_customers (GDPR consent_status gate)")
except Exception as e:
    print(f"  Row filter skipped (table may not exist yet): {e}")

# COMMAND ----------
# MAGIC %md ## 5. Table-Level Grants

TABLE_GRANTS: dict[str, dict[str, list[str]]] = {
    "bronze_customers": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT"],
        "mlops-data-scientists":  [],
        "mlops-read-only":        [],
    },
    "silver_customers": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT", "MODIFY"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        [],
    },
    "gold_customers_ml": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT", "MODIFY"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        ["SELECT"],
    },
    "customer_churn_features": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT", "MODIFY"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        [],
    },
    "churn_predictions": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        ["SELECT"],
    },
    "actual_outcomes": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT", "MODIFY"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        [],
    },
    "model_performance_actuals": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        ["SELECT"],
    },
    "model_monitoring_log": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT"],
        "mlops-data-scientists":  ["SELECT"],
        "mlops-read-only":        ["SELECT"],
    },
    "operational_monitoring_log": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT"],
        "mlops-data-scientists":  [],
        "mlops-read-only":        [],
    },
    "retraining_trigger_log": {
        "mlops-platform-admins":  ["ALL PRIVILEGES"],
        "mlops-ml-engineers":     ["SELECT"],
        "mlops-data-scientists":  [],
        "mlops-read-only":        [],
    },
}

grant_count  = 0
revoke_count = 0

NON_ADMIN_GROUPS = ["mlops-data-scientists", "mlops-ml-engineers", "mlops-read-only"]

for table, group_privs in TABLE_GRANTS.items():
    full_table = f"`{catalog}`.`{schema}`.`{table}`"
    # Revoke non-admin grants first — ensures clean idempotent state
    for group in NON_ADMIN_GROUPS:
        try:
            spark.sql(f"REVOKE ALL PRIVILEGES ON TABLE {full_table} FROM `{group}`")
            revoke_count += 1
        except Exception:
            pass

    for group, privs in group_privs.items():
        if not privs:
            continue
        priv_str = ", ".join(privs)
        spark.sql(f"GRANT {priv_str} ON TABLE {full_table} TO `{group}`")
        print(f"  GRANT {priv_str:30} ON {table:35} TO {group}")
        grant_count += 1

print(f"\n✓ Applied {grant_count} grants across {len(TABLE_GRANTS)} tables")

# COMMAND ----------
# MAGIC %md ## 6. Grant EXECUTE on Masking Functions to Non-Admins
# MAGIC
# MAGIC Non-admin users must have EXECUTE on the masking function to run queries
# MAGIC against masked columns — without EXECUTE, queries fail rather than mask.

for fn in ["pii_mask_email", "pii_mask_phone", "pii_row_filter"]:
    full_fn = f"`{catalog}`.`{schema}`.`{fn}`"
    for group in ["mlops-ml-engineers", "mlops-data-scientists"]:
        try:
            spark.sql(f"GRANT EXECUTE ON FUNCTION {full_fn} TO `{group}`")
            print(f"  GRANT EXECUTE ON {fn} TO {group}")
        except Exception as e:
            print(f"  ⚠ EXECUTE grant skipped ({fn} / {group}): {e}")

# COMMAND ----------
# MAGIC %md ## 7. Delta Table Properties — CDF + Deletion Vectors

MANAGED_TABLES = [
    "silver_customers",
    "gold_customers_ml",
    "customer_churn_features",
    "churn_predictions",
    "actual_outcomes",
    "model_performance_actuals",
]

for table in MANAGED_TABLES:
    full_table = f"`{catalog}`.`{schema}`.`{table}`"
    try:
        spark.sql(f"""
            ALTER TABLE {full_table}
            SET TBLPROPERTIES (
                'delta.enableChangeDataFeed'   = 'true',
                'delta.enableDeletionVectors'  = 'true'
            )
        """)
        print(f"  ✓ CDF + DV enabled: {table}")
    except Exception as e:
        print(f"  {table}: {e}")

# COMMAND ----------
# MAGIC %md ## 8. Audit — Verify Masking Functions Applied

print("\n=== Column Masking Verification ===")
try:
    mask_check = spark.sql(f"""
        SELECT column_name, mask_name
        FROM system.information_schema.column_masks
        WHERE table_catalog = '{catalog}'
          AND table_schema   = '{schema}'
          AND table_name     = 'silver_customers'
    """)
    mask_check.show(truncate=False)
    if mask_check.count() == 0:
        print("  ⚠ No masks found — table may not exist yet or masks were not applied")
except Exception as e:
    print(f"  Mask verification query failed (non-fatal): {e}")

print("\n=== Row Filter Verification ===")
try:
    filter_check = spark.sql(f"""
        SELECT table_name, row_filter_name, row_filter_argument_names
        FROM system.information_schema.row_filters
        WHERE table_catalog = '{catalog}'
          AND table_schema   = '{schema}'
    """)
    filter_check.show(truncate=False)
except Exception as e:
    print(f"  Row filter verification query failed (non-fatal): {e}")

print("\n✓ Delta access controls, column masking, and table properties applied")
